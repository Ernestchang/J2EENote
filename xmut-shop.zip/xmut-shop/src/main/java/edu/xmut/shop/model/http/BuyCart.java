package edu.xmut.shop.model.http;

import java.util.ArrayList;
import java.util.List;

public class BuyCart {
	/* 购物项 */
	private List<BuyItem> items = new ArrayList<BuyItem>();

	public void addBuyItem(BuyItem item) {
		if (items.contains(item)) {// 如果购物项已经存在于购物车,累加其购买数量
			for (BuyItem bItem : items) {
				if (bItem.equals(item)) {
					bItem.setAmount(bItem.getAmount() + item.getAmount());
					break;
				}
			}
		} else {
			items.add(item);
		}
	}

	public void deleteBuyItem(BuyItem item) {
		if (this.items.contains(item)) {
			this.items.remove(item);
		}
	}

	public void deleteAll() {
		items.clear();
	}

	public List<BuyItem> getItems() {
		return items;
	}

	/**
	 * 计算商品的总金额
	 */
	public float getTotalPrice() {
		float result = 0f;
		for (BuyItem item : items) {
			result += item.getProduct().getPrice()* item.getAmount();
		}
		return result;
	}
}
