package edu.xmut.shop.web.action;

import com.opensymphony.xwork2.ActionSupport;

import edu.xmut.shop.model.http.Json;

public class BaseAction extends ActionSupport {
	private static final long serialVersionUID = -7101928527412399842L;
	protected static final String JSON = "json";
	protected Json json;
	public Json getJson() {
		return json;
	}
	public void setJson(Json json) {
		this.json = json;
	}
}
