package edu.xmut.shop.service;

import edu.xmut.shop.model.OrderItem;
import edu.xmut.shop.service.base.DAO;

public interface OrderItemService extends DAO<OrderItem> {

}
