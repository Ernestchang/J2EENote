package edu.xmut.shop.service;

import edu.xmut.shop.model.Privilege;
import edu.xmut.shop.service.base.DAO;

public interface PrivilegeService extends DAO<Privilege> {

}
