package edu.xmut.shop.web.action;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import edu.xmut.shop.model.Product;
import edu.xmut.shop.model.http.BuyCart;
import edu.xmut.shop.model.http.BuyItem;
import edu.xmut.shop.service.ProductService;
import edu.xmut.shop.utils.WebUtil;

@Controller
@Scope("prototype")
public class BuyCartAction extends BaseAction {
	private static final long serialVersionUID = -1941400839033465170L;
	@Resource
	private ProductService productService;
	private String id;
	private int amount;
	private String operator;

	public String add() throws Exception {
		BuyCart buyCart = (BuyCart) WebUtil.getFromSession("buyCart");
		if (buyCart == null) {
			buyCart = new BuyCart();
			WebUtil.addToSession("buyCart", buyCart);
		}
		if (id != null && !"".equals(id)) {
			Product product = productService.find(id);
			BuyItem buyItem = new BuyItem(product, amount);
			buyCart.addBuyItem(buyItem);
		}
		return "list";
	}
	public String deleteAll() throws Exception {
		BuyCart buyCart = (BuyCart) WebUtil.getFromSession("buyCart");
		if (buyCart != null) {
			buyCart.deleteAll();
		}
		return "list";
	}
	public String delete() throws Exception {
		BuyCart buyCart = (BuyCart) WebUtil.getFromSession("buyCart");
		if (buyCart != null) {
			buyCart.deleteBuyItem(new BuyItem(productService.find(id)));
		}
		return "list";
	}
	public String setAmount() throws Exception {
		BuyCart buyCart = (BuyCart) WebUtil.getFromSession("buyCart");
		if (buyCart == null) {
			buyCart = new BuyCart();
			WebUtil.addToSession("buyCart", buyCart);
		}
		BuyItem tItem = new BuyItem(productService.find(id));
		for(BuyItem item : buyCart.getItems()){
			if(item.equals(tItem)) {
				if("add".equals(operator)) {
					item.setAmount(item.getAmount() + 1);
				} else {
					item.setAmount(item.getAmount() - 1);
				}
			}
		}
		return "list";
	}
	
	public String execute() throws Exception {
		return "buyCart";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}

}
