package edu.xmut.shop.service.impl;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.service.CustomerService;
import edu.xmut.shop.service.base.DaoSupport;
import edu.xmut.shop.utils.MD5;
@Service @Transactional @SuppressWarnings("unchecked")
public class CustomerServiceBean extends DaoSupport<Customer> implements CustomerService {

	public void updatePassword(String username, String newpassword){
		em.createQuery("update Customer o set o.password=?1 where o.username=?2")
		.setParameter(1, MD5.MD5Encode(newpassword)).setParameter(2, username).executeUpdate();
	}
	@Override
	public void save(Customer entity) {
		entity.setPassword(MD5.MD5Encode(entity.getPassword()));
		super.save(entity);
	}

	@Transactional(propagation=Propagation.NOT_SUPPORTED,readOnly=true)
	public boolean exsit(String username){
		long count = (Long)em.createQuery("select count(o) from Customer o where o.username=?1").setParameter(1, username)
			.getSingleResult();
		return count>0;
	}
	
	public Customer checkUser(String username, String password){
		List<Customer> list = em.createQuery("select o from Customer o where o.username=?1 and o.password=?2 and o.visible=?3")
				.setParameter(1, username).setParameter(2, MD5.MD5Encode(password)).setParameter(3, true).getResultList();
		if(list.size() == 1) {
			return list.get(0);
		}
		return null;
	}
	
}
