package edu.xmut.shop.service;

import edu.xmut.shop.model.Product;
import edu.xmut.shop.service.base.DAO;

public interface ProductService extends DAO<Product> {

}
