package edu.xmut.shop.service;

import edu.xmut.shop.model.PrivilegeGroup;
import edu.xmut.shop.service.base.DAO;

public interface PrivilegeGroupService extends DAO<PrivilegeGroup> {

}
