package edu.xmut.shop.service;

import edu.xmut.shop.model.Order;
import edu.xmut.shop.service.base.DAO;

public interface OrderService extends DAO<Order> {

}
