package edu.xmut.shop.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.model.Product;
import edu.xmut.shop.model.http.Json;
import edu.xmut.shop.service.CustomerService;
import edu.xmut.shop.service.ProductService;
@Controller
public class SystemInitAction extends BaseAction {
	private static final long serialVersionUID = 1L;
	@Resource
	private CustomerService customerService;
	@Resource
	private ProductService productService;
	
	@Override
	public String execute() throws Exception {
		initCustomer();
		initProduct();
		json = new Json();
		json.setMsg("系统初始化成功");
		return JSON;
	}
	
	public void initCustomer() {
		if(customerService.getCount() == 0) {
			Customer customer = new Customer();
			customer.setUsername("wanghao");
			customer.setPassword("bingo");
			customerService.save(customer);
		}
	}
	
	public void initProduct() {
		if(productService.getCount() == 0) {
			String description = "";
			for(int i = 0; i < 10; i++) {
				description += "洛杉矶的分类收集到了斯蒂芬。";
			}
			for(int i = 0; i < 100; i++) {
				Product product = new Product("产品" + i, 22.5f, "test.jpg", description);
				productService.save(product);
			}
		}
	}
}
