package edu.xmut.shop.web.action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import edu.xmut.shop.model.Product;
import edu.xmut.shop.model.http.PageView;
import edu.xmut.shop.service.ProductService;
import edu.xmut.shop.utils.WebUtil;

@Controller
@Scope("prototype")
public class ProductAction extends BaseAction {
	private static final long serialVersionUID = -1941400839033465170L;
	@Resource
	private ProductService productService;
	private String keyword = "";
	private int page = 1;
	private String id;

	public String list() throws Exception {
		PageView<Product> pageView = new PageView<Product>(9, page);
		if (keyword != null && !"".equals(keyword)) {
			StringBuffer jpql = new StringBuffer("");
			List<Object> params = new ArrayList<Object>();
			jpql.append(" o.name like ?").append((params.size()+1));
			params.add("%"+ keyword + "%");
			jpql.append(" or  o.description like ?").append((params.size()+1));
			params.add("%"+ keyword + "%");
			pageView.setQueryResult(productService.getScrollData(pageView.getFirstResult(), 
					pageView.getMaxresult(), jpql.toString(), params.toArray()));
		} else {
			pageView.setQueryResult(productService.getScrollData(pageView.getFirstResult(), pageView.getMaxresult()));
		}
		WebUtil.addToRequest("pageView", pageView);
		WebUtil.addToRequest("keyword", keyword);
		return "list";
	}
	
	public String detail() throws Exception {
		WebUtil.addToRequest("entry", productService.find(id));
		return "detail";
	}

	public String getKeyword() {
		return keyword;
	}

	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}

	public int getPage() {
		return page < 1 ? 1 : page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
}
