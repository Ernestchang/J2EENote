package edu.xmut.shop.web.action;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.model.http.Json;
import edu.xmut.shop.service.CustomerService;
import edu.xmut.shop.utils.WebUtil;

@Controller
public class CustomerAuthAction extends BaseAction {
	private static final long serialVersionUID = -1941400839033465170L;
	@Resource
	private CustomerService customerService;
	private String username;
	private String password;
	public String login() throws Exception {
		json = new Json();
		if(username != null && !"".equals(username.trim())) {
			if(password != null && !"".equals(password.trim())) {
				Customer customer = customerService.checkUser(username, password);
				if(customer != null) {
					WebUtil.addToSession("customer", customer);
					json.setSuccess(true);
				} else {
					json.setSuccess(false);
					json.setMsg("用户名或密码错误");
				}
			} else {
				json.setSuccess(false);
				json.setMsg("密码不能为空");
			}
		} else {
			json.setSuccess(false);
			json.setMsg("用户名不能为空");
		}
		return JSON;
	}
	
	public String logout() throws Exception {
		WebUtil.deleteFromSession("customer");
		return "customerAuth";
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
