package edu.xmut.shop.service;

import edu.xmut.shop.model.Manager;
import edu.xmut.shop.service.base.DAO;

public interface ManagerService extends DAO<Manager> {

}
