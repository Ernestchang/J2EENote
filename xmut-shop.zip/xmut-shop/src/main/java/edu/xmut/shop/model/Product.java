package edu.xmut.shop.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "t_product")
public class Product extends BaseBean implements Serializable {
	private static final long serialVersionUID = -7999578735086908980L;
	private String name;
	private Float price;
	private String picture;
	private String description;

	public Product() {
	}
	public Product(String name, Float price, String picture, String description) {
		this.name = name;
		this.price = price;
		this.picture = picture;
		this.description = description;
	}

	@Column(length = 10, nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(nullable = false)
	public Float getPrice() {
		return price;
	}

	public void setPrice(Float price) {
		this.price = price;
	}

	@Column(length = 50, nullable = false)
	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	@Column(length = 150, nullable = false)
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}
}
