package edu.xmut.shop.web.action;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.model.Order;
import edu.xmut.shop.model.OrderItem;
import edu.xmut.shop.model.http.BuyCart;
import edu.xmut.shop.model.http.BuyItem;
import edu.xmut.shop.model.http.PageView;
import edu.xmut.shop.service.OrderService;
import edu.xmut.shop.utils.WebUtil;

@Controller
@Scope("prototype")
public class OrderAction extends BaseAction {
	private static final long serialVersionUID = -1941400839033465170L;
	@Resource
	private OrderService orderService;
	private String name;
	private String address;
	private String phone;
	private int page = 1;
	
	public String confirmcontactinfo() throws Exception {
		return "confirmcontactinfo";
	}
	public String saveorder() throws Exception {
		BuyCart buyCart = (BuyCart) WebUtil.getFromSession("buyCart");
		Order order = new Order();
		order.setName(name);
		order.setAddress(address);
		order.setPhone(phone);
		order.setCustomer((Customer)WebUtil.getFromSession("customer"));
		for(BuyItem item : buyCart.getItems()){
			OrderItem orderItem = new OrderItem(item.getProduct(),item.getAmount());
			order.getOrderItems().add(orderItem);
			orderItem.setOrder(order);
		}
		orderService.save(order);
		WebUtil.deleteFromSession("buyCart");
		return bought();
	}
	public String bought() throws Exception {
		PageView<Order> pageView = new PageView<Order>(9, page);
		StringBuffer jpql = new StringBuffer("");
		List<Object> params = new ArrayList<Object>();
		jpql.append(" o.customer = ?").append((params.size()+1));
		params.add((Customer)WebUtil.getFromSession("customer"));
		pageView.setQueryResult(orderService.getScrollData(pageView.getFirstResult(), 
				pageView.getMaxresult(), jpql.toString(), params.toArray()));
		WebUtil.addToRequest("pageView", pageView);
		return "bought";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
}
