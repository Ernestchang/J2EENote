package edu.xmut.shop.service;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.service.base.DAO;

public interface CustomerService extends DAO<Customer> {
	public boolean exsit(String username);
	public Customer checkUser(String username, String password);
	public void updatePassword(String username, String newpassword);
}