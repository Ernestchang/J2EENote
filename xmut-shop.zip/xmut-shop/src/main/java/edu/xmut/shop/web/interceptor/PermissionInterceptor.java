package edu.xmut.shop.web.interceptor;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionInvocation;
import com.opensymphony.xwork2.interceptor.AbstractInterceptor;

import edu.xmut.shop.model.Customer;
import edu.xmut.shop.utils.WebUtil;

public class PermissionInterceptor extends AbstractInterceptor {
	private static final long serialVersionUID = -4431977378844348269L;
	
	@Override
	public String intercept(ActionInvocation invocation) throws Exception {
		if(!isLogin()) {
			return "customerAuth";
		}
		return invocation.invoke();
	}
	/**
	 * 判断用户是否登录
	 * @return
	 */
	private boolean isLogin() {
		String uri = ServletActionContext.getRequest().getRequestURI();
		//如果用户未登录，重定向到用户登陆界面
		Customer customer = (Customer) WebUtil.getFromSession("customer");
		if(uri.contains("front") && null == customer){
			return false;
		}
		return true;
	}
}
