package edu.xmut.shop.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.xmut.shop.model.Order;
import edu.xmut.shop.service.OrderService;
import edu.xmut.shop.service.base.DaoSupport;
@Service @Transactional
public class OrderServiceBean extends DaoSupport<Order> implements OrderService {

}
