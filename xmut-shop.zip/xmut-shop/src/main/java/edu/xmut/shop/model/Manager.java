package edu.xmut.shop.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "t_manager")
public class Manager extends User implements Serializable {
	private static final long serialVersionUID = 7316246915367911712L;
	private Set<PrivilegeGroup> privilegeGroups = new HashSet<PrivilegeGroup>();

	@ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinTable(name = "t_manager_privilegegroup", inverseJoinColumns = @JoinColumn(name = "privilegegroup_id"), joinColumns = @JoinColumn(name = "manager_id"))
	public Set<PrivilegeGroup> getPrivilegeGroups() {
		return privilegeGroups;
	}

	public void setPrivilegeGroups(Set<PrivilegeGroup> privilegeGroups) {
		this.privilegeGroups = privilegeGroups;
	}
}
