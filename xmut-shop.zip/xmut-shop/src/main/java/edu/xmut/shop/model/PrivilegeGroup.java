package edu.xmut.shop.model;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "t_privilegegroup")
public class PrivilegeGroup extends BaseBean implements Serializable {
	private static final long serialVersionUID = 6056228278152934555L;
	private String name;
	private Set<Privilege> privileges = new HashSet<Privilege>();
	private Set<Manager> managers = new HashSet<Manager>();

	@Column(length = 10, nullable = false)
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@ManyToMany(cascade = CascadeType.REFRESH, fetch = FetchType.EAGER)
	@JoinTable(
			name="t_privilegegroup_privilege",
			inverseJoinColumns=@JoinColumn(name="privilege_id"),
			joinColumns=@JoinColumn(name="privilegegroup_id")
		)
	public Set<Privilege> getPrivileges() {
		return privileges;
	}

	public void setPrivileges(Set<Privilege> privileges) {
		this.privileges = privileges;
	}

	@ManyToMany(mappedBy = "privilegeGroups", cascade = CascadeType.REFRESH)
	public Set<Manager> getManagers() {
		return managers;
	}

	public void setManagers(Set<Manager> managers) {
		this.managers = managers;
	}
}
