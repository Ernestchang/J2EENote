package edu.xmut.shop.utils;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionContext;

public class WebUtil {

	public static void addToRequest(String key, Object value) {
		ActionContext.getContext().put(key, value);
	}

	public static Object getFromRequest(String key) {
		return ActionContext.getContext().get(key);
	}

	public static void addToSession(String key, Object value) {
		ActionContext.getContext().getSession().put(key, value);
	}

	public static Object getFromSession(String key) {
		return ActionContext.getContext().getSession().get(key);
	}

	public static void deleteFromSession(String key) {
		ActionContext.getContext().getSession().remove(key);
	}

	public static String getContextPath() {
		return ServletActionContext.getRequest().getContextPath();
	}

	public static String getRealPath(String pathdir) {
		return ServletActionContext.getServletContext().getRealPath(pathdir);
	}

	public static void addToCookie(String name, String value, int maxAge) {
		Cookie cookie = new Cookie(name, value);
        cookie.setPath("/");
        if (maxAge>0) cookie.setMaxAge(maxAge);
        ServletActionContext.getResponse().addCookie(cookie);
	}

	public static String getRequestPath() {
		HttpServletRequest request = ServletActionContext.getRequest();
		String requestPath = request.getRequestURI() + "?" + request.getQueryString();
		if (requestPath.indexOf("&") > -1) {// 去掉其他参数
			requestPath = requestPath.substring(0, requestPath.indexOf("&"));
		}
		requestPath = requestPath.substring(request.getContextPath().length());// 去掉项目路径
		return requestPath;
	}
}
