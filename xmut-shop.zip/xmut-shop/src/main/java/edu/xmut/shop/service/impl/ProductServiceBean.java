package edu.xmut.shop.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import edu.xmut.shop.model.Product;
import edu.xmut.shop.service.ProductService;
import edu.xmut.shop.service.base.DaoSupport;
@Service @Transactional
public class ProductServiceBean extends DaoSupport<Product> implements ProductService {

}
