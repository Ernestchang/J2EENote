$(function() {
	$("#login").submit(function() {
		$.post("customerAuthAction!login.action", $(this).serialize(), function(json) {
			if (json.success) {
				window.location.href = "front/productAction!list.action";
			} else {
				alert(json.msg);
			}
		}, "json");
		return false;
	});
});