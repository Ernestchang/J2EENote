function topage(page) {
	var keyword = $("#keyword").val();
	if(keyword) {
		window.location.href = "front/productAction!list.action?page=" + page + "&keyword=" + keyword;
	} else {
		window.location.href = "front/productAction!list.action?page=" + page;
	}
}
$(function() {
	
	$("#keyword").on('keyup', function(event) {
		if (event.keyCode == '13') {
			topage(1);
		}
	});
	
});