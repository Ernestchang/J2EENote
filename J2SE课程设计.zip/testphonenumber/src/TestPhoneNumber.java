//**********************************************************
//����������               ѧ�ţ�1007092136
//**********************************************************
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
@SuppressWarnings("serial")
public class TestPhoneNumber extends JFrame implements ActionListener
{
	JTextArea result;
	JTextField area; 
	JButton tijiao,qingchu,tuichu;
	JPanel panel1,panel2,panel3,panel4;
	boolean a = false;
	public TestPhoneNumber()
	{
		setTitle("�ֻ���������");
		Container c = getContentPane();
		result = new JTextArea("�������ֻ�����",3,10);
		result.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		result.setFont(new Font("��Բ", Font.BOLD, 14));
		result.setEditable(false);
		result.setLineWrap(true);
		result.setPreferredSize(new Dimension(250,50));
		result.setBackground(new Color(200,200,252));
		panel1 = new JPanel();
		panel1.setBackground(new Color(229,238,250));
		panel1.add(result);
		area = new JTextField(22);
		area.setPreferredSize(new Dimension(250,30));
		area.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		area.setBackground(new Color(235,235,252));
		panel2 = new JPanel();
		panel2.setPreferredSize(new Dimension(250,35));
		panel2.setBackground(new Color(229,238,250));
		panel2.add(area);
		tijiao = new JButton("��ʼ���");
		tijiao.setFont(new Font("��Բ", Font.BOLD, 13));
		tijiao.setPreferredSize(new Dimension(79,30));
		tijiao.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		tijiao.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		tijiao.addActionListener(this);
		qingchu = new JButton("ȫ�����");
		qingchu.setFont(new Font("��Բ", Font.BOLD, 13));
		qingchu.setPreferredSize(new Dimension(79,30));
		qingchu.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		qingchu.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		qingchu.addActionListener(this);
		tuichu = new JButton("�˳�");
		tuichu.setFont(new Font("��Բ", Font.BOLD, 13));
		tuichu.setPreferredSize(new Dimension(79,30));
		tuichu.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		tuichu.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		tuichu.addActionListener(this);
		panel3 = new JPanel();
		panel3.setPreferredSize(new Dimension(250,35));
		panel3.setBackground(new Color(229,238,250));
		panel3.add(tijiao);
		panel3.add(qingchu);
		panel3.add(tuichu);
		panel4 = new JPanel();
		panel4.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		panel4.setBackground(new Color(229,238,250));
		panel4.setLayout(new BoxLayout(panel4,BoxLayout.Y_AXIS));
		panel4.add(panel1);
		panel4.add(panel2);
		panel4.add(panel3);
		c.add(panel4);
		pack();
		setResizable(false);
		setVisible(true);
    }
	public void actionPerformed(ActionEvent e)
	{
		Object event = e.getSource();
		if(event == tijiao)
		{
			String s1 = "";
			int total = 0;
			for(int i = 0;i < area.getText().length();i++)
			{
				if(area.getText().charAt(i)<'0'||area.getText().charAt(i)>'9')
					s1 += area.getText().charAt(i);
				else
					total++;
			}
			if(s1.equals("") == false)
			{
				result.setText("�����Ƿ��ַ���                                   "+s1);
			}
			else
			{
				if(total < 11)
					result.setText("�ú���С�ڣ���λ");
				if(total > 11)
					result.setText("�ú�����ڣ���λ ");
				if(total == 11)
					result.setText("���ֻ�������Ϲ���");	
			}
		}
		if(event == qingchu)
		{
			area.setText("");
			result.setText("�������ֻ�����");
		}
		if(event == tuichu)
			System.exit(0);
	}
	public static void main(String[] args)
	{
		TestPhoneNumber test = new TestPhoneNumber();
		test.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}