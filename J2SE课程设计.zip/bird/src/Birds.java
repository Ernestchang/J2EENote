//**********************************************************
//����������               ѧ�ţ�1007092136
//**********************************************************
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
@SuppressWarnings("serial")
public class Birds extends JFrame implements ActionListener,MouseListener,MouseMotionListener
{
	JPanel panel1;
	JLabel bk,shu;
	JLabel zhu1,zhu2,zhu3,zhu4,niao,tiankong1,tiankong2,defen,result,result2;
	JButton start,chonglai;
	ImageIcon bk1,bk2,bk3,bk4,bk5,bk6,zhu,over;
	int moveX,moveY,x1,y1,kong = 0,score = 0;
	Timer timer;
	Toolkit tk;
	Image image;
	Cursor mycursor;
	boolean a = false,b = false,c = false,d = false,aa = true,bb = true,cc = true,dd = true;
	Point point1 = null,point2 = null;
	public Birds()
	{
		setTitle("��ŭ��С��");
		Container c = getContentPane();
		tk = Toolkit.getDefaultToolkit();
		image = tk.getImage("kai1.png");
		mycursor = tk.createCustomCursor(image,new Point(10,10),"xxx");
		setCursor(mycursor);
		timer = new Timer(0,this);
		over = new ImageIcon("over.png");
		bk1 = new ImageIcon("bk1.png");
		bk2 = new ImageIcon("bk2.png");
		bk3 = new ImageIcon("bk3.png");
		bk4 = new ImageIcon("bk4.png");
		bk5 = new ImageIcon("bk5.png");
		bk6 = new ImageIcon("bk6.png");
		niao = new JLabel(new ImageIcon("niao.png"));
		niao.setSize(30,30);
		niao.setVisible(false);
		niao.addMouseListener(this);
		zhu1 = new JLabel(new ImageIcon("zhu.png"));
		zhu1.setSize(30,30);
		zhu1.setLocation(552,334);
		zhu1.setVisible(true);
		zhu1.addMouseListener(this);
		zhu2 = new JLabel(new ImageIcon("zhu.png"));
		zhu2.setSize(30,30);
		zhu2.setLocation(620,334);
		zhu2.setVisible(true);
		zhu2.addMouseListener(this);
		zhu3 = new JLabel(new ImageIcon("zhu.png"));
		zhu3.setSize(30,30);
		zhu3.setLocation(681,334);
		zhu3.setVisible(true);
		zhu3.addMouseListener(this);
		zhu4 = new JLabel(new ImageIcon("zhu.png"));
		zhu4.setSize(30,30);
		zhu4.setLocation(773,293);
		zhu4.setVisible(true);
		zhu4.addMouseListener(this);
	    bk = new JLabel();
	    bk.setIcon(bk1);
		bk.setBounds(0, 0,bk1.getIconWidth(), bk1.getIconHeight());
		start = new JButton(new ImageIcon("kaishi.png"));
		start.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(image,new Point(10,10),"xxx"));
		start.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		start.setPreferredSize(new Dimension(100,50));
		start.setFont(new Font("��Բ", Font.BOLD, 16));
		start.addActionListener(this);
		chonglai = new JButton(new ImageIcon("chonglai.png"));
		chonglai.setCursor(Toolkit.getDefaultToolkit().createCustomCursor(image,new Point(10,10),"xxx"));
		chonglai.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		chonglai.setPreferredSize(new Dimension(100,50));
		chonglai.setFont(new Font("��Բ", Font.BOLD, 16));
		chonglai.addActionListener(this);
		result = new JLabel("����ǰ�÷�Ϊ��");
		tiankong1 = new JLabel();
		tiankong1.setPreferredSize(new Dimension(80,0));
		tiankong2 = new JLabel();
		tiankong2.setPreferredSize(new Dimension(200,50));
		defen = new JLabel(new ImageIcon("defen.png"));
		result2 = new JLabel("0");
		result2.setFont(new Font("��Բ",Font.BOLD,25));
		panel1 = new JPanel();
		panel1.add(start);
		panel1.add(tiankong1);
		panel1.add(chonglai);
		panel1.add(tiankong2);
		panel1.add(defen);
		panel1.add(result2);
		panel1.setOpaque(false);
		panel1.addMouseListener(this);
		panel1.addMouseMotionListener(this);
		c.add(zhu1);
		c.add(zhu2);
		c.add(zhu3);
		c.add(zhu4);
		c.add(niao);
		c.add(panel1);
		((JPanel)this.getContentPane()).setOpaque(false);
		this.getLayeredPane().add(bk, new Integer(Integer.MIN_VALUE));
		setSize(new Dimension(bk1.getIconWidth(), bk1.getIconHeight()));
		setResizable(false);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();
		if(source == start)
		{
			a = true;
			image = tk.getImage("kai2.png");
			mycursor = tk.createCustomCursor(image,new Point(10,10),"xxx");
			setCursor(mycursor);
			x1 = 238;
			y1 = 334;
			niao.setLocation(x1,y1);
			timer.start();
		}
		if(source == chonglai)
		{
			tiankong2.setIcon(new ImageIcon("kong.png"));
			a = false;
			b = false;
			c = false;
			d = false;
			aa = true;
			bb = true;
			cc = true;
			dd = true;
			score = 0;
			result2.setText(""+score);
			zhu1.setVisible(true);
			zhu2.setVisible(true);
			zhu3.setVisible(true);
			zhu4.setVisible(true);
			kong = 0;
			bk.setIcon(bk1);
			image = tk.getImage("kai2.png");
			mycursor = tk.createCustomCursor(image,new Point(10,10),"xxx");
			setCursor(mycursor);
			timer.stop();
		}
		if(c)
		{
			if(kong == 1)
				bk.setIcon(bk2);
			if(kong == 2)
				bk.setIcon(bk3);
			if(kong == 3)
				bk.setIcon(bk4);
			if(kong == 4)
				bk.setIcon(bk5);
			if(d)
			{
				moveX = (point1.x - point2.x)/8;
				moveY = (point1.y - point2.y)/8;
				d = false;
			}
			x1 += moveX;
	        y1 += moveY;
	        moveY += 1;
	        if(y1 <= 0)
	        	moveY= moveY * -1;
	        if(x1 >= 950 || y1>=510)
	        {
				a = true;
				c = false;
				niao.setVisible(false);
				x1 = 238;
				y1 = 334;
				niao.setLocation(x1,y1);
				timer.stop();
	        }
	        niao.setLocation(x1,y1);
		}
		if(Math.pow(niao.getLocation().x-zhu1.getLocation().x,2)
				+Math.pow(niao.getLocation().x-zhu1.getLocation().x,2) < 10&&aa)
		{
			a = true;
			c = false;
			aa = false;
			zhu1.setVisible(false);
			niao.setVisible(false);
			x1 = 238;
			y1 = 334;
			niao.setLocation(x1,y1);
			score++;
			result2.setText(""+score);
			timer.stop();
		}
		if(Math.pow(niao.getLocation().x-zhu2.getLocation().x,2)
				+Math.pow(niao.getLocation().x-zhu2.getLocation().x,2) < 10&&bb)
		{
			a = true;
			c = false;
			bb = false;
			zhu2.setVisible(false);
			niao.setVisible(false);
			x1 = 238;
			y1 = 334;
			niao.setLocation(x1,y1);
			score++;
			result2.setText(""+score);
			timer.stop();
		}
		if(Math.pow(niao.getLocation().x-zhu3.getLocation().x,2)
				+Math.pow(niao.getLocation().x-zhu3.getLocation().x,2) < 10&cc)
		{
			a = true;
			c = false;
			cc = false;
			zhu3.setVisible(false);
			niao.setVisible(false);
			x1 = 238;
			y1 = 334;
			niao.setLocation(x1,y1);
			score++;
			result2.setText(""+score);
			timer.stop();
		}
		if(Math.pow(niao.getLocation().x-zhu4.getLocation().x,2)
				+Math.pow(niao.getLocation().x-zhu4.getLocation().x,2) < 10&&dd)
		{
			a = true;
			c = false;
			dd = false;
			zhu4.setVisible(false);
			niao.setVisible(false);
			x1 = 238;
			y1 = 334;
			niao.setLocation(x1,y1);
			score++;
			result2.setText(""+score);
			timer.stop();
		}
		if(a&&kong==4)
		{
			a = false;
			tiankong2.setIcon(over);
			niao.setVisible(false);
			timer.stop();
		}
	}
	public void mousePressed(MouseEvent e)
	{
		image = tk.getImage("tuo.png");
		mycursor = tk.createCustomCursor(image,new Point(10,10),"xxx");
		setCursor(mycursor);
		if(a)
		{
			a = false;
			b = true;
			point1 = e.getPoint();
		}
	}
	public void mouseReleased(MouseEvent e)
	{
		image = tk.getImage("kai2.png");
		mycursor = tk.createCustomCursor(image,new Point(10,10),"xxx"); 
		setCursor(mycursor);
		if(b)
		{
			point2 = e.getPoint();
			b = false;
			c = true;
			d = true;
			timer.start();
			kong++;
			niao.setVisible(true);
		}
	}
	public void mouseClicked(MouseEvent e){}
	public void mouseEntered(MouseEvent e){}
	public void mouseExited(MouseEvent e){}
	public void mouseDragged(MouseEvent e){}
	public void mouseMoved(MouseEvent e){}
	public static void main(String[] args)
	{
		Birds killmouse = new Birds();
	  	killmouse.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
