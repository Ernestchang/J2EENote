import java.awt.*;
import java.util.Random;
public class Circle
{
	public int centerX, centerY,x,y,radius,r,g,b;
	public Color color;
	public Random generator;
	public Circle()
	{
		radius = 3;
		generator = new Random();
		r = generator.nextInt(255);
		g = generator.nextInt(255);
		b = generator.nextInt(255);
		color = new Color(r,g,b);
        x=generator.nextInt(8);
        y=generator.nextInt(8);
	    centerX = Math.abs(generator.nextInt(450));
	    centerY = Math.abs(generator.nextInt(450));
	}
	public void draw(Graphics page)
	{	 
		if (centerX<0||centerX>450)
			x=-x;
		if (centerY<0||centerY>450)
			y=-y;
	    page.setColor(color);
	    centerX+=x;
	    centerY+=y;
		page.fillOval(centerX-radius,centerY-radius,radius*2,radius*2);
	}
}