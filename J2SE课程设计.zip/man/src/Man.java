//**********************************************************
//����������               ѧ�ţ�1007092136
//**********************************************************
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
@SuppressWarnings("serial")
public class Man extends JFrame implements ActionListener
{
	JPanel panel1;
	Circle zidan[];
	Timer timer;
	public Man()
	{
		setTitle("�����˾ͼ��20��");
		Container c = getContentPane();
		panel1 = new JPanel();
		c.add(panel1);
		setSize(450,450);
		setResizable(false);
		setVisible(true);
		
	}
	public void actionPerformed(ActionEvent arg0)
	{
		
	}
	public static void main(String[] args)
	{
		Man frame = new Man();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
