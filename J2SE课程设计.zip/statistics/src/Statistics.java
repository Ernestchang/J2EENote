//**********************************************************
//����������               ѧ�ţ�1007092136
//**********************************************************
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.BevelBorder;
@SuppressWarnings("serial")
public class Statistics extends JFrame implements ActionListener
{
	JTextArea text,result;
	JButton button;
	JScrollPane jp;
	JPanel panel1,panel2,panel3,panel4;
	String s,jieguo;
	boolean a = false;
	int total1 = 0,total2 = 0;
	public Statistics()
	{
		setTitle("�ı�ͳ��");
		Container c = getContentPane();
		text = new JTextArea(6,20);
		text.setLineWrap(true);
		text.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		text.setBackground(new Color(240,245,254));
		jp=new JScrollPane(text);
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		panel1.setBackground(new Color(214,221,239));
		panel1.add(jp);
		result = new JTextArea(4,21);
		result.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		result.setBackground(new Color(240,245,254));
		result.setEditable(false);
		panel2 = new JPanel();
		panel2.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		panel2.setBackground(new Color(214,221,239));
		panel2.add(result);
		button = new JButton("��ʼͳ��");
		button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		button.addActionListener(this);
		button.setFont(new Font("��Բ", Font.BOLD, 15));
		button.setPreferredSize(new Dimension(70,35));
		button.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
		panel3 = new JPanel();
		panel3.setBackground(new Color(214,221,239));
		panel3.add(button);
		panel4 = new JPanel();
		panel4.setBackground(new Color(214,221,239));
		panel4.setLayout(new BoxLayout(panel4,BoxLayout.Y_AXIS));
		panel4.add(panel1);
		panel4.add(panel2);
		panel4.add(panel3);
		c.add(panel4);
		pack();
		setResizable(false);
		setVisible(true);
	}
	
	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == button)
		{
			total1 = 0;
			total2 = 0;
			jieguo = "";
			s = "";
			s += text.getText();
			if(s.length() >0)
			{
				if(s.charAt(0) >= 'A' && s.charAt(0) <= 'Z' || s.charAt(0) >= 'a' && s.charAt(0) <= 'z')
				{
					total1++;
					a = true;
					for(int i = 1;i < s.length();i++)
					{
						if(s.charAt(i) >= 'A' && s.charAt(i) <= 'Z' || s.charAt(i) >= 'a' && s.charAt(i) <= 'z')
						{
							total1++;
							a = true;
						}
						else
						{
							if(a)
								total2++;
							a = false;
						}
					}
					if(s.charAt(s.length()-1) >= 'A' && s.charAt(s.length()-1) <= 'Z' ||
							s.charAt(s.length()-1) >= 'a' && s.charAt(s.length()-1) <= 'z')
					{
						total2++;
					}
				}
				else
				{
					for(int i = 1;i < s.length();i++)
					{
						if(s.charAt(i) >= 'A' && s.charAt(i) <= 'Z' || s.charAt(i) >= 'a' && s.charAt(i) <= 'z')
						{
							total1++;
							a = true;
						}
						else
						{
							if(a)
								total2++;
							a = false;
						}
					}
					if(s.charAt(s.length()-1) >= 'A' && s.charAt(s.length()-1) <= 'Z' ||
							s.charAt(s.length()-1) >= 'a' && s.charAt(s.length()-1) <= 'z')
					{
						total2++;
					}
				}
				jieguo += "   �ַ���(�ƿո�)                                 " + s.length();
				jieguo += "\n   ��ĸ��                                                " + total1;
				jieguo += "\n   ������                                                " + total2;
				if(total2 == 0)
					jieguo +="\n   ����ƽ������                                    " + 0;
				else
					jieguo += "\n   ����ƽ������                                    " + Double.toString((double)total1/(double)total2);
				result.setText(jieguo);
			}
			else
			{
				result.setText("");
			}
		}
	}
	public static void main(String[] args)
	{
		Statistics frame = new Statistics();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}