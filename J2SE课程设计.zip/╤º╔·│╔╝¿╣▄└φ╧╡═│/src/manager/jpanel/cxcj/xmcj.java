package manager.jpanel.cxcj;

import hacks.ColumnResizer;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

import CRUD.Manager;

//��������ѯ���
public class xmcj extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JTextField user = null;
	private JButton submit = null;
	private JLabel jLabel1 = null;
	private JScrollPane jScrollPane = null;
	private JTable jTable = null;
	private DefaultTableModel model = null;

	public xmcj() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BorderLayout());
		this.add(getJPanel(), BorderLayout.NORTH);
		this.add(getJPanel1(), BorderLayout.CENTER);
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jLabel1 = new JLabel("������ѧ������");
			jPanel = new JPanel();
			jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.X_AXIS));
			jPanel.add(Box.createRigidArea(new Dimension(10, 0)));
			jPanel.add(jLabel1);
			jPanel.add(Box.createRigidArea(new Dimension(5, 0)));
			jPanel.add(getUser());
			jPanel.add(Box.createRigidArea(new Dimension(20, 0)));
			jPanel.add(getSubmit());
			jPanel.add(Box.createRigidArea(new Dimension(300, 0)));
		}
		return jPanel;
	}

	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BorderLayout());
			jPanel1.add(getJScrollPane(), BorderLayout.CENTER);
		}
		return jPanel1;
	}

	private JTextField getUser() {
		if (user == null) {
			user = new JTextField(null);
		}
		return user;
	}

	private JButton getSubmit() {
		if (submit == null) {
			submit = new JButton("ȷ��");
			submit.addActionListener(this);
		}
		return submit;
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJTable());
		}
		return jScrollPane;
	}

	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable();
			jTable.setEnabled(false);
		}
		return jTable;
	}

	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {
			if (user.getText().trim().equals(""))
				JOptionPane.showMessageDialog(this, "������ѧ������", "������ʾ",
						JOptionPane.INFORMATION_MESSAGE);
			else {
				model = Manager.getNameScoreTabelModel(user.getText());
				if (model != null) {
					jTable.setModel(model);  //���ñ���model
					ColumnResizer.Resizer(jTable);   //���������п�
				} else
					JOptionPane.showMessageDialog(this, "��������ȷ��ѧ������", "������ʾ",
							JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}

}
