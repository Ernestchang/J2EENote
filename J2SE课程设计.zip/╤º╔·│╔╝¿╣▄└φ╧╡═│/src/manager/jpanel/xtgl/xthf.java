package manager.jpanel.xtgl;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import CRUD.BackupRecovery;

import java.awt.BorderLayout;
import java.io.File;
import java.util.Vector;

//��excel���ж�ȡ���ݻָ�����˫���ı���
public class xthf extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private JList jList = null;
	private Vector<String> vector = null;
	private JFileChooser chooser = null;
	private File file = null;
	private String tableName = null;

	public xthf() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BorderLayout());
		this.add(getJList(), BorderLayout.CENTER);

	}

	private JList getJList() {
		if (jList == null) {
			vector = new Vector<String>();
			vector.addElement("ManagerTable");
			vector.addElement("StudentTable");
			vector.addElement("TeacherTable");
			vector.addElement("ScoreTable");
			vector.addElement("TeachTable");
			vector.addElement("CourseTable");
			jList = new JList(vector);
			jList.addMouseListener(this);
			jList.setBorder(BorderFactory.createTitledBorder("��˫����Ҫ�ָ��ı�������"));

		}
		return jList;
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == jList) {
			if (e.getClickCount() == 2) {
				tableName = (String) jList.getSelectedValue();
				chooser = new JFileChooser();
				chooser.showOpenDialog(null);
				file = chooser.getSelectedFile();
				System.out.println(file);
				if (tableName != null && file.toString() != null) {
					int rs = BackupRecovery.recovery(tableName, file);
					if(rs != 0)
						JOptionPane.showMessageDialog(null, "�ָ��ɹ�", "������ʾ",
								JOptionPane.INFORMATION_MESSAGE);
					else
						JOptionPane.showMessageDialog(null, "�ָ�ʧ��", "������ʾ",
								JOptionPane.WARNING_MESSAGE);

				}
			}
		}
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mousePressed(MouseEvent e) {
	}

	public void mouseReleased(MouseEvent e) {
	}

}
