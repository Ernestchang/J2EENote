package manager.jpanel.xtgl;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.File;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.JFileChooser;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import CRUD.BackupRecovery;

//���ݱ�����ı���excel�ļ���
public class xtbf extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private JList jList = null;
	private Vector<String> vector = null; // @jve:decl-index=0:
	private JFileChooser chooser = null;
	private File file = null;
	private String tableName = null;

	public xtbf() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BorderLayout());
		this.add(getJList(), BorderLayout.CENTER);
	}

	private JList getJList() {
		if (jList == null) {
			vector = new Vector<String>();
			vector.addElement("ManagerTable");
			vector.addElement("StudentTable");
			vector.addElement("TeacherTable");
			vector.addElement("ScoreTable");
			vector.addElement("TeachTable");
			vector.addElement("CourseTable");
			jList = new JList(vector);
			jList.addMouseListener(this);
			jList.setBorder(BorderFactory.createTitledBorder("��˫����Ҫ���ݵı�������"));
		}
		return jList;
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == jList) {
			if (e.getClickCount() == 2) {
				tableName = (String) jList.getSelectedValue();   //˫��Ҫ���ݵı�����ȡ������ı�������
				chooser = new JFileChooser();
				chooser.showSaveDialog(null);
				file = chooser.getSelectedFile();
				if (tableName != null && file.toString() != null) {
					boolean rs = BackupRecovery.backup(tableName, file);  //����CRUD���е�BackupRecovery�е�backup()�������ݱ�˫���ı�
					if(rs)
						JOptionPane.showMessageDialog(null, "���ݳɹ�", "������ʾ",
								JOptionPane.INFORMATION_MESSAGE);
					else
						JOptionPane.showMessageDialog(null, "����ʧ��", "������ʾ",
								JOptionPane.WARNING_MESSAGE);
				}
			}
		}
	}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public void mousePressed(MouseEvent e) {}

	public void mouseReleased(MouseEvent e) {}

}
