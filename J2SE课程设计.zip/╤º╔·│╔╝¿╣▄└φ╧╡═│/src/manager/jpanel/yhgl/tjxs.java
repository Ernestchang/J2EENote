package manager.jpanel.yhgl;

import info.studentinfo;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import Listener.IDListener;
import Listener.PSListener;
import CRUD.Manager;

//����ѧ�����
public class tjxs extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JTextField id = null;
	private JTextField name = null;
	private JPasswordField ps = null;
	private JButton submit = null;
	private JButton reset = null;
	private JTextField cid = null;
	private JTextField cname = null;

	public tjxs() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		this.add(Box.createRigidArea(new Dimension(100, 0)));
		this.add(getJPanel());
		this.add(Box.createRigidArea(new Dimension(30, 0)));
		this.add(getJPanel1());
		this.add(Box.createRigidArea(new Dimension(100, 0)));
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BoxLayout(getJPanel(), BoxLayout.Y_AXIS));
			jPanel.add(getId());
			jPanel.add(Box.createRigidArea(new Dimension(0, 5)));
			jPanel.add(getSname());
			jPanel.add(Box.createRigidArea(new Dimension(0, 5)));
			jPanel.add(getCid());
			jPanel.add(Box.createRigidArea(new Dimension(0, 5)));
			jPanel.add(getCname());
			jPanel.add(Box.createRigidArea(new Dimension(0, 5)));
			jPanel.add(getPs());
		}
		return jPanel;
	}

	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BoxLayout(getJPanel1(), BoxLayout.Y_AXIS));
			jPanel1.add(Box.createRigidArea(new Dimension(0, 100)));
			jPanel1.add(getSubmit());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 40)));
			jPanel1.add(getReset());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 100)));
		}
		return jPanel1;
	}

	private JTextField getId() {
		if (id == null) {
			id = new JTextField();
			id.setBorder(BorderFactory.createTitledBorder("������ѧ��ID"));
			id.addKeyListener(new IDListener());
		}
		return id;
	}

	private JTextField getSname() {
		if (name == null) {
			name = new JTextField();
			name.setBorder(BorderFactory.createTitledBorder("������ѧ������"));
		}
		return name;
	}

	private JPasswordField getPs() {
		if (ps == null) {
			ps = new JPasswordField();
			ps.addKeyListener(new PSListener());
			ps.setBorder(BorderFactory.createTitledBorder("������ѧ������"));
		}
		return ps;
	}

	private JButton getSubmit() {
		if (submit == null) {
			submit = new JButton("�ύ");
			submit.addActionListener(this);
		}
		return submit;
	}

	private JButton getReset() {
		if (reset == null) {
			reset = new JButton("����");
			reset.addActionListener(this);
		}
		return reset;
	}

	private JTextField getCid() {
		if (cid == null) {
			cid = new JTextField();
			cid.setBorder(BorderFactory.createTitledBorder("������༶ID"));
			cid.addKeyListener(new IDListener());
		}
		return cid;
	}

	private JTextField getCname() {
		if (cname == null) {
			cname = new JTextField();
			cname.setBorder(BorderFactory.createTitledBorder("������༶����"));
		}
		return cname;
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {
			if (id.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "ѧ�Ų���Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (name.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "ѧ��������Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (cid.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "�༶�Ų���Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (cname.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "�༶������Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (ps.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "ѧ�����벻��Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else {
				studentinfo.id = id.getText();
				studentinfo.name = name.getText();
				studentinfo.cid = cid.getText();
				studentinfo.cname = cname.getText();
				studentinfo.ps = ps.getText();
				boolean b = Manager.addStudent();
				if (b) {
					id.setText("");
					name.setText("");
					cid.setText("");
					cname.setText("");
					ps.setText("");
					JOptionPane.showMessageDialog(null, "���ӳɹ�", "������ʾ",
							JOptionPane.INFORMATION_MESSAGE);
				} else
					JOptionPane.showMessageDialog(null, "����ʧ��", "������ʾ",
							JOptionPane.WARNING_MESSAGE);
			}
		}
		if (e.getSource() == reset) {
			id.setText("");
			name.setText("");
			cid.setText("");
			cname.setText("");
			ps.setText("");
		}
	}

}
