package manager.jpanel.yhgl;

import info.idinfo;
import info.nameinfo;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;

import CRUD.Manager;

//ɾ����ʦ���
public class scjs extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private JList id = null;
	private String tid = null;
	private JScrollPane jScrollPane = null;
	private JPanel jPanel = null;
	private JLabel jLabel = null;
	private JSplitPane jSplitPane = null;
	private JList xm = null;

	public scjs() {
		super();
		initialize();
	}

	private void initialize() {
		Manager.getTIDNAME();
		jLabel = new JLabel("   �̹���                                                      ����");
		this.setLayout(new BorderLayout());
		this.add(getJPanel(), BorderLayout.CENTER);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJSplitPane());

		}
		return jScrollPane;
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setBorder(BorderFactory.createTitledBorder("��˫����Ҫɾ���Ľ̹��Ż��ʦ��"));
			jPanel.setLayout(new BorderLayout());
			jPanel.add(jLabel, BorderLayout.NORTH);
			jPanel.add(getJScrollPane(), BorderLayout.CENTER);
		}
		return jPanel;
	}

	private JSplitPane getJSplitPane() {
		if (jSplitPane == null) {
			jSplitPane = new JSplitPane();
			jSplitPane.setDividerSize(2);
			jSplitPane.setEnabled(false);
			jSplitPane.setDividerLocation(200);
			jSplitPane.setLeftComponent(getXh());
			jSplitPane.setRightComponent(getXm());

		}
		return jSplitPane;
	}

	private JList getXh() {
		if (id == null) {
			id = new JList(idinfo.tid);
			id.addMouseListener(this);
		}
		return id;
	}

	private JList getXm() {
		if (xm == null) {
			xm = new JList();
			xm = new JList(nameinfo.tname);
			xm.addMouseListener(this);
		}
		return xm;
	}

	public void action() {
		tid = (String) id.getSelectedValue();
		if (tid != null) {
			int i = JOptionPane.showConfirmDialog(null, "ȷ��Ҫɾ���ý�ʦ��?",
					"������ʾ", JOptionPane.YES_NO_OPTION);
			if (i == JOptionPane.YES_OPTION) {
				int rs = Manager.deleteTeacher(tid);
				if (rs != 0) {
					Manager.getTIDNAME();
					JOptionPane.showMessageDialog(null, "ɾ�������ɹ�","������ʾ", JOptionPane.INFORMATION_MESSAGE);
				} else
					JOptionPane.showMessageDialog(null, "ɾ������ʧ��","������ʾ", JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2)
			action();       //���jlist�Ǳ�������ξʹ򿪶Ի���
	}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public void mousePressed(MouseEvent e) {
		if(e.getSource() == xm) {
			id.setSelectedIndex(xm.getSelectedIndex());   //�����̹��ű�ѡ��ʱ��ʹ��Ӧ�Ľ�ʦ��Ҳ��ѡ��
		}
		if(e.getSource() == id)
			xm.setSelectedIndex(id.getSelectedIndex());  //������ʦ����ѡ��ʱ��ʹ��Ӧ�Ľ̹���Ҳ��ѡ��
	}

	public void mouseReleased(MouseEvent e) {}

}
