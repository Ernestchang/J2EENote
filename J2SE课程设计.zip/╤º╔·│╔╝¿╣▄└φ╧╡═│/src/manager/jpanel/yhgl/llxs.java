package manager.jpanel.yhgl;

import hacks.ColumnResizer;

import java.awt.BorderLayout;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

import CRUD.Manager;

//�������ѧ����Ϣ���
public class llxs extends JPanel {

	private static final long serialVersionUID = 1L;
	private JScrollPane jScrollPane = null;
	private JTable jTable = null;
	private DefaultTableModel model = null;

	public llxs() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BorderLayout());
		this.add(getJScrollPane(), BorderLayout.CENTER);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJTable());
		}
		return jScrollPane;
	}

	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable();
			model = Manager.getStudentTableModel();
			jTable.setModel(model);
			ColumnResizer.Resizer(jTable);
			jTable.setEnabled(false);
		}
		return jTable;
	}

}