package manager.jpanel.yhgl;

import info.idinfo;
import info.nameinfo;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import CRUD.Manager;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.JSplitPane;

//ɾ��ѧ�����
public class scxs extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private JList xh = null;
	private String sid = null;
	private JScrollPane jScrollPane = null;
	private JPanel jPanel = null;
	private JLabel jLabel = null;
	private JSplitPane jSplitPane = null;
	private JList xm = null;

	public scxs() {
		super();
		initialize();
	}

	private void initialize() {
		Manager.getSIDNAME();
		jLabel = new JLabel("   ѧ��                                                           ����");
		this.setLayout(new BorderLayout());
		this.add(getJPanel(), BorderLayout.CENTER);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJSplitPane());

		}
		return jScrollPane;
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setBorder(BorderFactory.createTitledBorder("��˫����Ҫɾ����ѧ�Ż�ѧ����"));
			jPanel.setLayout(new BorderLayout());
			jPanel.add(jLabel, BorderLayout.NORTH);
			jPanel.add(getJScrollPane(), BorderLayout.CENTER);
		}
		return jPanel;
	}

	private JSplitPane getJSplitPane() {
		if (jSplitPane == null) {
			jSplitPane = new JSplitPane();
			jSplitPane.setDividerSize(2);
			jSplitPane.setEnabled(false);
			jSplitPane.setDividerLocation(200);
			jSplitPane.setLeftComponent(getXh());
			jSplitPane.setRightComponent(getXm());

		}
		return jSplitPane;
	}

	private JList getXh() {
		if (xh == null) {
			xh = new JList(idinfo.sid);
			xh.addMouseListener(this);
		}
		return xh;
	}

	private JList getXm() {
		if (xm == null) {
			xm = new JList();
			xm = new JList(nameinfo.sname);
			xm.addMouseListener(this);
		}
		return xm;
	}

	public void action() {
		sid = (String) xh.getSelectedValue();
		if (sid != null) {
			int i = JOptionPane.showConfirmDialog(null, "ȷ��Ҫɾ����ѧ����?",
					"������ʾ", JOptionPane.YES_NO_OPTION);
			if (i == JOptionPane.YES_OPTION) {
				int rs = Manager.deleteStudent(sid);
				if (rs != 0) {
					Manager.getSIDNAME();
					JOptionPane.showMessageDialog(null, "ɾ�������ɹ�",
							"������ʾ", JOptionPane.INFORMATION_MESSAGE);
				}
				else
					JOptionPane.showMessageDialog(null, "ɾ������ʧ��",
							"������ʾ", JOptionPane.WARNING_MESSAGE);
			}
		}
	}

	public void mouseClicked(MouseEvent e) {
		if (e.getClickCount() == 2)    //���jlist�Ǳ�������ξʹ򿪶Ի���
			action();
	}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public void mousePressed(MouseEvent e) {
		if(e.getSource() == xm)
			xh.setSelectedIndex(xm.getSelectedIndex());    //����ѧ�ű�ѡ��ʱ��ʹ��Ӧ������Ҳ��ѡ��
		if(e.getSource() == xh)
			xm.setSelectedIndex(xh.getSelectedIndex());  //����������ѡ��ʱ��ʹ��Ӧ��ѧ��Ҳ��ѡ��
	}

	public void mouseReleased(MouseEvent e) {}

}
