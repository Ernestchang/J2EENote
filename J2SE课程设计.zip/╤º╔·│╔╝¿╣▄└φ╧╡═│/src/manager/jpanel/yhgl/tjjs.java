package manager.jpanel.yhgl;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

import CRUD.Manager;
import Listener.IDListener;
import Listener.PSListener;
import info.teacherinfo;

//���ӽ�ʦ���
public class tjjs extends JPanel implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JTextField id = null;
	private JTextField name = null;
	private JPasswordField ps = null;
	private JButton submit = null;
	private JButton reset = null;

	public tjjs() {
		super();
		initialize();
	}

	private void initialize() {
		this.setLayout(new BoxLayout(this, BoxLayout.X_AXIS));
		this.add(Box.createRigidArea(new Dimension(100, 0)));
		this.add(getJPanel());
		this.add(Box.createRigidArea(new Dimension(30, 0)));
		this.add(getJPanel1());
		this.add(Box.createRigidArea(new Dimension(100, 0)));
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BoxLayout(getJPanel(), BoxLayout.Y_AXIS));
			jPanel.add(Box.createRigidArea(new Dimension(0, 50)));
			jPanel.add(getId());
			jPanel.add(Box.createRigidArea(new Dimension(0, 30)));
			jPanel.add(getTname());
			jPanel.add(Box.createRigidArea(new Dimension(0, 30)));
			jPanel.add(getPs());
			jPanel.add(Box.createRigidArea(new Dimension(0, 50)));
		}
		return jPanel;
	}

	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BoxLayout(getJPanel1(), BoxLayout.Y_AXIS));
			jPanel1.add(Box.createRigidArea(new Dimension(0, 100)));
			jPanel1.add(getSubmit());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 40)));
			jPanel1.add(getReset());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 100)));
		}
		return jPanel1;
	}

	private JTextField getId() {
		if (id == null) {
			id = new JTextField();
			id.setBorder(BorderFactory.createTitledBorder("�������ʦID"));
			id.addKeyListener(new IDListener());
		}
		return id;
	}

	private JTextField getTname() {
		if (name == null) {
			name = new JTextField();
			name.setBorder(BorderFactory.createTitledBorder("�������ʦ����"));
		}
		return name;
	}

	private JPasswordField getPs() {
		if (ps == null) {
			ps = new JPasswordField();
			ps.addKeyListener(new PSListener());
			ps.setBorder(BorderFactory.createTitledBorder("�������ʦ����"));
		}
		return ps;
	}

	private JButton getSubmit() {
		if (submit == null) {
			submit = new JButton("�ύ");
			submit.addActionListener(this);
		}
		return submit;
	}

	private JButton getReset() {
		if (reset == null) {
			reset = new JButton("����");
			reset.addActionListener(this);
		}
		return reset;
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == submit) {

			if (id.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "��ʦ�Ų���Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (name.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "��ʦ������Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else if (ps.getText().trim().equals(""))
				JOptionPane.showMessageDialog(null, "��ʦ���벻��Ϊ��", "������ʾ",
						JOptionPane.WARNING_MESSAGE);
			else {
				teacherinfo.id = id.getText();
				teacherinfo.name = name.getText();
				teacherinfo.ps = ps.getText();
				int i = Manager.addTeacher();
				if (i != 0) {
					id.setText("");
					name.setText("");
					ps.setText("");
					JOptionPane.showMessageDialog(null, "���ӳɹ�", "������ʾ",
							JOptionPane.INFORMATION_MESSAGE);
				} else
					JOptionPane.showMessageDialog(null, "����ʧ��", "������ʾ",
							JOptionPane.WARNING_MESSAGE);
			}
		}
		if (e.getSource() == reset) {
			id.setText("");
			name.setText("");
			ps.setText("");
		}
	}

}
