package frame;

import info.managerinfo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagLayout;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JTextField;

import CRUD.Login;
import CRUD.Student;
import CRUD.Teacher;
import Listener.IDListener;
import Listener.PSListener;

//��¼����
public class LoginFrame extends JFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel primary = null;
	private JButton login = null;
	private JButton reset = null;
	private JRadioButton manager = null;
	private JRadioButton teacher = null;
	private JRadioButton student = null;
	private ButtonGroup group = null;
	private JPanel lrPanel = null;
	private JPanel leftPanel = null;
	private JPanel djPanel = null;
	private JPanel buttonPanel = null;
	private JTextField user = null;
	private JPasswordField ps = null;
	private JPanel upPanel = null;
	private Thread thread = null;
	private Window window = null;
	private ImageIcon img = null;
	private keyListener kl = null;

	//���췽��
	public LoginFrame() {
		super("ѧ������ϵͳ");
		getWindow();
		initialize();
	}

	//��ʼ����¼����
	private void initialize() {
		kl = new keyListener();
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/title.png")));    //���ô���ͼ��
		this.setBackground(new Color(234, 244, 254));
		this.setSize(new Dimension(269, 220));
		this.setPreferredSize(new Dimension(260, 220));
		this.setContentPane(getPrimary());
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setVisible(true);
	}

	private JButton getLogin() {
		if (login == null) {
			login = new JButton("��½");
			login.setBackground(new Color(234, 244, 254));
			login.setPreferredSize(new Dimension(80, 25));
			login.addActionListener(this);
			login.addKeyListener(kl);
		}
		return login;
	}

	private JButton getReset() {
		if (reset == null) {
			reset = new JButton("����");
			reset.setBackground(new Color(234, 244, 254));
			reset.setPreferredSize(new Dimension(80, 25));
			reset.addActionListener(this);
			reset.addKeyListener(kl);
		}
		return reset;
	}

	private JRadioButton getManager() {
		if (manager == null) {
			manager = new JRadioButton("����Ա", true);
			manager.setBackground(new Color(234, 244, 254));
		}
		return manager;
	}

	private JRadioButton getTeacher() {
		if (teacher == null) {
			teacher = new JRadioButton("��ʦ");
			teacher.setBackground(new Color(234, 244, 254));
		}
		return teacher;
	}

	private JRadioButton getStudent() {
		if (student == null) {
			student = new JRadioButton("ѧ��");
			student.setBackground(new Color(234, 244, 254));
		}
		return student;
	}

	private void initUserGroup() {
		if (group == null) {
			group = new ButtonGroup();
			group.add(manager);
			group.add(teacher);
			group.add(student);
		}
	}

	private JPanel getLrPanel() {
		if (lrPanel == null) {
			lrPanel = new JPanel();
			lrPanel.setLayout(new BoxLayout(lrPanel, BoxLayout.Y_AXIS));
			lrPanel.setBackground(new Color(234, 244, 254));
			lrPanel.add(Box.createRigidArea(new Dimension(0, 3)));
			lrPanel.add(getUser());
			lrPanel.add(Box.createRigidArea(new Dimension(0, 3)));
			lrPanel.add(getPs());
		}
		return lrPanel;
	}

	//��ʾ�û���������
	private JPanel getLeftPanel() {
		if (leftPanel == null) {
			leftPanel = new JPanel();
			leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.X_AXIS));
			leftPanel.setBackground(new Color(234, 244, 254));
			leftPanel.add(new JLabel(new ImageIcon(getClass().getResource("/images/zuo.png"))));
			leftPanel.add(getLrPanel());
			leftPanel.add(Box.createRigidArea(new Dimension(60, 0)));
		}
		return leftPanel;
	}

	//�ȼ����
	private JPanel getDjPanel() {
		if (djPanel == null) {
			djPanel = new JPanel();
			djPanel.setLayout(new BoxLayout(djPanel, BoxLayout.X_AXIS));
			djPanel.setBackground(new Color(234, 244, 254));
			djPanel.add(getManager());
			djPanel.add(getTeacher());
			djPanel.add(getStudent());
			djPanel.add(Box.createRigidArea(new Dimension(60, 0)));
			initUserGroup();   //�󶨵�ѡ��ť
		}
		return djPanel;
	}

	//��ť���
	private JPanel getButtonPanel() {
		if (buttonPanel == null) {
			buttonPanel = new JPanel();
			buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.X_AXIS));
			buttonPanel.setBackground(new Color(234, 244, 254));
			buttonPanel.add(getLogin());
			buttonPanel.add(Box.createRigidArea(new Dimension(30, 0)));
			buttonPanel.add(getReset());
			buttonPanel.add(Box.createRigidArea(new Dimension(100, 0)));
		}
		return buttonPanel;
	}

	//�˺������
	private JTextField getUser() {
		if (user == null) {
			user = new JTextField();
			user.setColumns(10);
			user.addKeyListener(new IDListener());
		}
		return user;
	}

	//���������
	private JPasswordField getPs() {
		if (ps == null) {
			ps = new JPasswordField();
			ps.addKeyListener(new PSListener());
		}
		return ps;
	}

	//װ�ض���ͼƬ�����
	private JPanel getUpPanel() {
		if (upPanel == null) {
			upPanel = new JPanel();
			upPanel.setLayout(new GridBagLayout());
			upPanel.setBackground(new Color(234, 244, 254));
			upPanel.add(new JLabel(new ImageIcon(getClass().getResource("/images/up.png"))));
		}
		return upPanel;
	}

	//�����
	private JPanel getPrimary() {
		if (primary == null) {
			primary = new JPanel();
			primary.setBackground(new Color(234, 244, 254));
			primary.setLayout(new BoxLayout(primary, BoxLayout.Y_AXIS));
			primary.setPreferredSize(new Dimension(150, 163));
			primary.add(getUpPanel());
			primary.add(getLeftPanel());
			primary.add(Box.createRigidArea(new Dimension(0, 5)));
			primary.add(getDjPanel());
			primary.add(Box.createRigidArea(new Dimension(0, 5)));
			primary.add(getButtonPanel());
			primary.add(Box.createRigidArea(new Dimension(0, 10)));
		}
		return primary;
	}

	@SuppressWarnings({ "static-access", "deprecation" })
	//��ʼͼƬ����
	private Window getWindow() {
		if (window == null) {
			try {
				img = new ImageIcon("welcome.png");
				window = new Window(this);
				window.add(new JLabel(img));
				int x = Toolkit.getDefaultToolkit().getScreenSize().width / 2
						- img.getIconWidth() / 2;
				int y = Toolkit.getDefaultToolkit().getScreenSize().height / 2
						- img.getIconHeight() / 2;
				window.setLocation(x, y);
				window.pack();
				window.setVisible(true);
				window.toFront();
				thread = new Thread();
				thread.sleep(1000);    //����ͼƬ������ʾ1����
				window.dispose();
				thread.stop();
			} catch (Exception exception) {
				exception.printStackTrace();
			}
		}
		return window;
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent event) {
		if (event.getSource() == login) {
			boolean isLogin = false;
			if (manager.isSelected()) {
				isLogin = Login.isManager(user.getText(), ps.getText());   //�жϹ���Ա�˺ź������Ƿ���ȷ
				if (isLogin) {
					managerinfo.id = user.getText().trim();     //��¼����Ա�˺�
					managerinfo.ps = ps.getText().trim();     //��¼����Ա���룬�Ժ������޸�����ʱ�ȶ���������ԭ����
					dispose();   //���ٵ�¼����
					new MainFrame(1);   //�򿪹���Ա��������
				} else
					JOptionPane.showMessageDialog(null, "�û������������\n����������","������ʾ", JOptionPane.WARNING_MESSAGE);
			}
			if (teacher.isSelected()) {
				isLogin = Login.isTeacher(user.getText(), ps.getText());    //�жϽ�ʦ�˺ź������Ƿ���ȷ
				if (isLogin) {
					Teacher.saveTeacher(user.getText());    //���浱ǰ��ʦ��������Ϣ
					dispose();
					new MainFrame(2);  //�򿪽�ʦ��������
				} else
					JOptionPane.showMessageDialog(null, "�û������������\n����������",
							"������ʾ", JOptionPane.WARNING_MESSAGE);
			}
			if (student.isSelected()) {
				isLogin = Login.isStudent(user.getText(), ps.getText());
				if (isLogin) {
					Student.saveStudent(user.getText());
					dispose();
					new MainFrame(3);
				} else
					JOptionPane.showMessageDialog(null, "�û������������\n����������",
							"������ʾ", JOptionPane.WARNING_MESSAGE);
			}
		}
		//��յ�¼������е�������Ϣ
		if (event.getSource() == reset) {
			user.setText("");
			ps.setText("");
			student.setSelected(true);
		}
	}

	//���̼�����
	public class keyListener extends KeyAdapter {
		@SuppressWarnings("deprecation")
		public void keyPressed(KeyEvent e) {
			if (e.getSource() == login) {
				boolean isLogin = false;
				if (manager.isSelected()) {
					isLogin = Login.isManager(user.getText(), ps.getText());
					if (isLogin) {
						managerinfo.id = user.getText().trim();
						managerinfo.ps = ps.getText().trim();
						dispose();
						new MainFrame(1);
					} else
						JOptionPane.showMessageDialog(null, "�û������������\n����������",
								"������ʾ", JOptionPane.WARNING_MESSAGE);
				}
				if (teacher.isSelected()) {
					isLogin = Login.isTeacher(user.getText(), ps.getText());
					if (isLogin) {
						Teacher.saveTeacher(user.getText());
						dispose();
						new MainFrame(2);
					} else
						JOptionPane.showMessageDialog(null, "�û������������\n����������",
								"������ʾ", JOptionPane.WARNING_MESSAGE);
				}
				if (student.isSelected()) {
					isLogin = Login.isStudent(user.getText(), ps.getText());
					if (isLogin) {
						Student.saveStudent(user.getText());
						dispose();
						new MainFrame(3);
					} else
						JOptionPane.showMessageDialog(null, "�û������������\n����������",
								"������ʾ", JOptionPane.WARNING_MESSAGE);
				}
			}
			if (e.getSource() == reset) {
				user.setText("");
				ps.setText("");
				student.setSelected(true);
			}
		}
	}

}