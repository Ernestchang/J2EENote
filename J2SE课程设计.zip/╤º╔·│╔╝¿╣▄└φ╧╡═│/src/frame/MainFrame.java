package frame;

import toolbar.*;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class MainFrame extends JFrame {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private ImageIcon beijing = null;
	private JDesktopPane desktop = null;
	private int kind = 0;

	public MainFrame(int kind) {
		super("ѧ���ɼ�����ϵͳ");
		this.kind = kind;
		initialize();
	}

	//���ݵ�¼���ڴ��ݽ����Ĳ�����������Ӧ��JTooBar
	private void initialize() {
		beijing = new ImageIcon("beijing.png");
		this.setLayout(new BorderLayout());
		this.getContentPane().add(getDesktop(), BorderLayout.CENTER);
		if (kind == 1)
			this.getContentPane().add(new manager(this,desktop), BorderLayout.SOUTH);
		if (kind == 2)
			this.getContentPane().add(new teacher(this,desktop), BorderLayout.SOUTH);
		if (kind == 3)
			this.getContentPane().add(new student(this,desktop), BorderLayout.SOUTH);
		int x = Toolkit.getDefaultToolkit().getScreenSize().width / 2 - beijing.getIconWidth() / 2;
		int y = Toolkit.getDefaultToolkit().getScreenSize().height / 2 - beijing.getIconHeight() / 2;
		this.setIconImage(Toolkit.getDefaultToolkit().getImage(getClass().getResource("/images/title.png")));
		this.setPreferredSize(new Dimension(beijing.getIconWidth(), beijing.getIconHeight()));
		this.setLocation(x, y);
		this.pack();
		this.setResizable(false);  //���ô��ڴ�С���ɸı�
		this.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);
		this.setVisible(true);
	}

	//�����û��򿪵Ĵ��ڶ�����ʾ�ڴ�JDesktopPane��
	private JDesktopPane getDesktop() {
		if (desktop == null) {
			desktop = new JDesktopPane();
			desktop.setOpaque(false);
			jLabel = new JLabel(beijing);
			desktop.add(jLabel, new Integer(Integer.MIN_VALUE));
			jLabel.setBounds(0, 0, beijing.getIconWidth(), beijing.getIconHeight());
		}
		return desktop;
	}

}
