package toolbar;

import frame.Shift;
import info.teacherinfo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JToolBar;
import javax.swing.JLabel;
import javax.swing.JButton;

import teacher.jiframe.*;

//��ʦ������
public class teacher extends JToolBar implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JDesktopPane desktopPane = null;
	private JButton exit = null;
	private JButton xgmm = null;
	private JButton cjgl = null;
	private JLabel user = null;
	private JButton shift = null;
	private JFrame owner = null;

	public teacher(JFrame owner,JDesktopPane desktopPane) {
		super();
		this.owner = owner;
		this.desktopPane = desktopPane;
		initialize();
	}

	private void initialize() {
		user = new JLabel("�̹��ţ�" + teacherinfo.id + "  ������" + teacherinfo.name);
		user.setForeground(Color.red);
		jLabel = new JLabel(new ImageIcon(getClass().getResource(
				"/images/teacher.png")));
		this.add(jLabel);
		this.addSeparator();
		this.add(getCjgl());
		this.addSeparator();
		this.add(getXgmm());
		this.addSeparator();
		this.add(getShift());
		this.addSeparator();
		this.add(getExit());
		this.addSeparator(new Dimension(600, 0));
		this.add(user);
	}

	private JButton getCjgl() {
		if (cjgl == null) {
			cjgl = new JButton("�ɼ�����");
			cjgl.addActionListener(this);
		}
		return cjgl;
	}

	private JButton getXgmm() {
		if (xgmm == null) {
			xgmm = new JButton("�޸�����");
			xgmm.addActionListener(this);
		}
		return xgmm;
	}

	private JButton getShift() {
		if (shift == null) {
			shift = new JButton("�л��û�");
			shift.addActionListener(this);
		}
		return shift;
	}

	private JButton getExit() {
		if (exit == null) {
			exit = new JButton("�˳�ϵͳ");
			exit.addActionListener(this);
		}
		return exit;
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == cjgl) {
			desktopPane.add(new cjgl());
		}
		if (source == xgmm) {
			desktopPane.add(new xgmm());
		}
		if (source == shift) {
			owner.dispose();
			new Shift();
		}
		if (source == exit) {
			int result = JOptionPane.showConfirmDialog(null, "��ȷ���뿪��ϵͳ��",
					"������ʾ", JOptionPane.OK_CANCEL_OPTION);
			if (result == JOptionPane.OK_OPTION) {
				System.exit(0);
			}
		}
	}



}
