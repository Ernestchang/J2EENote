package toolbar;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JToolBar;

import frame.Shift;

import manager.jiframe.cxcj;
import manager.jiframe.xtgl;
import manager.jiframe.yhgl;

//����Ա������
public class manager extends JToolBar implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JLabel jLabel = null;
	private JButton xtgl = null;
	private JButton yhgl = null;
	private JButton cxcj = null;
	private JButton shift = null;
	private JButton exit = null;
	private JDesktopPane desktopPane = null;
	private JFrame owner = null;

	public manager(JFrame owner,JDesktopPane desktopPane) {
		super();
		this.owner = owner;
		this.desktopPane = desktopPane;
		initialize();
	}

	private void initialize() {
		jLabel = new JLabel(new ImageIcon(getClass().getResource("/images/manager.png")));
		this.add(jLabel);
		this.addSeparator();
		this.add(getXtgl());
		this.addSeparator();
		this.add(getYhgl());
		this.addSeparator();
		this.add(getCxcj());
		this.addSeparator();
		this.add(getShift());
		this.addSeparator();
		this.add(getExit());
	}

	private JButton getXtgl() {
		if (xtgl == null) {
			xtgl = new JButton("ϵͳ����");
			xtgl.addActionListener(this);
		}
		return xtgl;
	}

	private JButton getYhgl() {
		if (yhgl == null) {
			yhgl = new JButton("�û�����");
			yhgl.addActionListener(this);
		}
		return yhgl;
	}

	private JButton getCxcj() {
		if (cxcj == null) {
			cxcj = new JButton("��ѯ�ɼ�");
			cxcj.addActionListener(this);
		}
		return cxcj;
	}

	private JButton getShift() {
		if (shift == null) {
			shift = new JButton("�л��û�");
			shift.addActionListener(this);
		}
		return shift;
	}

	private JButton getExit() {
		if (exit == null) {
			exit = new JButton("�˳�ϵͳ");
			exit.addActionListener(this);
		}
		return exit;
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == xtgl) {
			desktopPane.add(new xtgl());
		}
		if (source == yhgl) {
			desktopPane.add(new yhgl());
		}
		if (source == cxcj) {
			desktopPane.add(new cxcj());
		}
		if (source == shift) {
			owner.dispose();
			new Shift();
		}
		if (source == exit) {
			int result = JOptionPane.showConfirmDialog(null, "��ȷ���뿪��ϵͳ��",
					"������ʾ", JOptionPane.OK_CANCEL_OPTION);
			if (result == JOptionPane.OK_OPTION) {
				System.exit(0);
			}
		}
	}

}