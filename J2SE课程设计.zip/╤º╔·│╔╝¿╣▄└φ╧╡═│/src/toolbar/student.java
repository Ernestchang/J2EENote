package toolbar;

import frame.Shift;
import info.studentinfo;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JToolBar;

import student.jiframe.llcj;
import student.jiframe.xgmm;
import java.awt.Color;

//ѧ��������
public class student extends JToolBar implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JDesktopPane desktopPane = null;
	private JLabel jLabel = null;
	private JButton ckcj = null;
	private JButton xgmm = null;
	private JButton shift = null;
	private JButton exit = null;
	private JLabel user = null;
	private JFrame owner = null;

	public student(JFrame owner,JDesktopPane desktopPane) {
		super();
		this.owner = owner;
		this.desktopPane = desktopPane;
		initialize();
	}

	private void initialize() {
		user = new JLabel("ѧ�ţ�" + studentinfo.id + "  ������" + studentinfo.name);
		user.setForeground(Color.red);
		jLabel = new JLabel(new ImageIcon(getClass().getResource("/images/student.png")));
		this.add(jLabel);
		this.addSeparator();
		this.add(getCkcj());
		this.addSeparator();
		this.add(getXgmm());
		this.addSeparator();
		this.add(getShift());
		this.addSeparator();
		this.add(getExit());
		this.addSeparator(new Dimension(690, 0));
		this.add(user);
	}

	private JButton getCkcj() {
		if (ckcj == null) {
			ckcj = new JButton("�鿴�ɼ�");
			ckcj.addActionListener(this);
		}
		return ckcj;
	}

	private JButton getXgmm() {
		if (xgmm == null) {
			xgmm = new JButton("�޸�����");
			xgmm.addActionListener(this);
		}
		return xgmm;
	}

	private JButton getShift() {
		if (shift == null) {
			shift = new JButton("�л��û�");
			shift.addActionListener(this);
		}
		return shift;
	}

	private JButton getExit() {
		if (exit == null) {
			exit = new JButton("�˳�ϵͳ");
			exit.addActionListener(this);
		}
		return exit;
	}

	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == ckcj) {
			desktopPane.add(new llcj());
		}
		if (source == xgmm) {
			desktopPane.add(new xgmm());
		}
		if (source == shift) {
			owner.dispose();
			new Shift();
		}
		if (source == exit) {
			int result = JOptionPane.showConfirmDialog(null, "��ȷ���뿪��ϵͳ��",
					"������ʾ", JOptionPane.OK_CANCEL_OPTION);
			if (result == JOptionPane.OK_OPTION) {
				System.exit(0);
			}
		}
	}

}
