package student.jiframe;

import info.studentinfo;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;

import CRUD.Student;
import Listener.PSListener;

//ѧ���޸��������
public class xgmm extends JInternalFrame implements ActionListener {

	private static final long serialVersionUID = 1L;
	private JPanel jPanel = null;
	private JPanel jPanel1 = null;
	private JPanel jPanel2 = null;
	private JPasswordField yps = null;
	private JPasswordField xps = null;
	private JPasswordField qps = null;
	private JButton submit = null;
	private JButton reset = null;

	public xgmm() {
		super("�޸�����", false, true, false, true);// ָ�����⡢�ɵ������ɹرա�����󻯺Ϳ�ͼ�껯
		initialize();
	}

	private void initialize() {
		this.setFrameIcon(new ImageIcon(getClass().getResource(
				"/images/student.png")));
		this.setBounds(350, 100, 400, 250);
		this.setContentPane(getJPanel());
		this.setVisible(true);
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setLayout(new BoxLayout(getJPanel(), BoxLayout.X_AXIS));
			jPanel.add(Box.createRigidArea(new Dimension(55, 0)));
			jPanel.add(getJPanel1());
			jPanel.add(Box.createRigidArea(new Dimension(20, 0)));
			jPanel.add(getJPanel2());
			jPanel.add(Box.createRigidArea(new Dimension(55, 0)));
		}
		return jPanel;
	}

	private JPanel getJPanel1() {
		if (jPanel1 == null) {
			jPanel1 = new JPanel();
			jPanel1.setLayout(new BoxLayout(getJPanel1(), BoxLayout.Y_AXIS));
			jPanel1.add(Box.createRigidArea(new Dimension(0, 15)));
			jPanel1.add(getYps());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 10)));
			jPanel1.add(getXps());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 10)));
			jPanel1.add(getQps());
			jPanel1.add(Box.createRigidArea(new Dimension(0, 15)));
		}
		return jPanel1;
	}

	private JPanel getJPanel2() {
		if (jPanel2 == null) {
			jPanel2 = new JPanel();
			jPanel2.setLayout(new BoxLayout(getJPanel2(), BoxLayout.Y_AXIS));
			jPanel2.add(Box.createRigidArea(new Dimension(0, 50)));
			jPanel2.add(getSubmit());
			jPanel2.add(Box.createRigidArea(new Dimension(0, 30)));
			jPanel2.add(getReset());
			jPanel2.add(Box.createRigidArea(new Dimension(0, 50)));
		}
		return jPanel2;
	}

	private JPasswordField getYps() {
		if (yps == null) {
			yps = new JPasswordField();
			yps.addKeyListener(new PSListener());
			yps.setBorder(BorderFactory.createTitledBorder("������ԭ����"));
		}
		return yps;
	}

	private JPasswordField getXps() {
		if (xps == null) {
			xps = new JPasswordField();
			xps.addKeyListener(new PSListener());
			xps.setBorder(BorderFactory.createTitledBorder("������������"));
		}
		return xps;
	}

	private JPasswordField getQps() {
		if (qps == null) {
			qps = new JPasswordField();
			qps.addKeyListener(new PSListener());
			qps.setBorder(BorderFactory.createTitledBorder("�ٴ�����������"));
		}
		return qps;
	}

	private JButton getSubmit() {
		if (submit == null) {
			submit = new JButton("�ύ");
			submit.addActionListener(this);
		}
		return submit;
	}

	private JButton getReset() {
		if (reset == null) {
			reset = new JButton("����");
			reset.addActionListener(this);
		}
		return reset;
	}

	@SuppressWarnings("deprecation")
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == submit) {
			if(yps.getText().trim().equals(studentinfo.ps.trim()))
			{
				if(xps.getText().trim().equals("")){
					JOptionPane.showMessageDialog(null, "�����벻��Ϊ��", "������ʾ",
							JOptionPane.INFORMATION_MESSAGE);
				}
				else
				{
					if (xps.getText().trim().equals(qps.getText().trim()))
					{
						@SuppressWarnings("unused")
						int rs = Student.updatePS(xps.getText().trim());
						if (rs != 0)
						{
							JOptionPane.showMessageDialog(null, "�����޸ĳɹ�", "������ʾ",
									JOptionPane.INFORMATION_MESSAGE);
							studentinfo.ps = xps.getText().trim();
						}
						else
							JOptionPane.showMessageDialog(null, "�����޸�ʧ��", "������ʾ",
									JOptionPane.WARNING_MESSAGE);
					} else
						JOptionPane.showMessageDialog(null, "���������벻һ��", "������ʾ",
								JOptionPane.WARNING_MESSAGE);
				}
			}
			else
				JOptionPane.showMessageDialog(null, "ԭ�������",
						"������ʾ", JOptionPane.WARNING_MESSAGE);
		}
		if (source == reset) {
			yps.setText("");
			xps.setText("");
			qps.setText("");
		}
	}

}
