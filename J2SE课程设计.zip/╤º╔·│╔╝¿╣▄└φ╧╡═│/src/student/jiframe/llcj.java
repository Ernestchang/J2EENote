package student.jiframe;

import hacks.ColumnResizer;

import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ImageIcon;
import javax.swing.table.DefaultTableModel;

import CRUD.Student;

//ѧ������ɼ����
public class llcj extends JInternalFrame {

	private static final long serialVersionUID = 1L;
	private JScrollPane jScrollPane = null;
	private JTable jTable = null;
	private DefaultTableModel model = null;

	public llcj() {
		super("����ɼ�", false, true, false, true);// ָ�����⡢�ɵ������ɹرա�����󻯺Ϳ�ͼ�껯
		initialize();
	}

	private void initialize() {
		this.setFrameIcon(new ImageIcon(getClass().getResource(
				"/images/student.png")));
		this.setBounds(350, 100, 450, 400);
		this.setContentPane(getJScrollPane());
		this.setVisible(true);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJTable());
		}
		return jScrollPane;
	}

	private JTable getJTable() {
		if (jTable == null) {
			jTable = new JTable();
			try {
				model = Student.getScoreModel();
				jTable.setModel(model);
				ColumnResizer.Resizer(jTable);
				jTable.setEnabled(false);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return jTable;
	}

}
