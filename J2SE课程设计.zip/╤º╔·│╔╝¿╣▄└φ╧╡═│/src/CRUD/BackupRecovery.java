package CRUD;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

import datasource1.JdbcUtils;

//ϵͳ���ݺ�ϵͳ�ָ���
public class BackupRecovery {

	//�ѹ��췽������Ϊ˽�У����ñ����ʵ������ֻ�ܵ��ø���ľ�̬����
	private BackupRecovery() {}

	//�����ݿ�������ݵ�����excel�ļ���
	public static boolean backup(String tableName, File file) {
		FileWriter output = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		int column = 0;
		try {
			output = new FileWriter(file);
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from " + tableName);
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			for (int i = 1; i <= column; i++) {
				output.write(rsmd.getColumnName(i) + "\t");
			}
			output.write("\n");
			while (rs.next()) {
				for (int i = 1; i <= column; i++) {
					output.write(rs.getString(i) + "\t");
				}
				output.write("\n");
			}
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
			try {
				output.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	//��excel�е����ݻָ������ݿ���
	public static int recovery(String tableName, File file) {
		FileReader input = null;
		BufferedReader br = null;
		Connection conn = null;
		PreparedStatement pstmt = null;
		StringBuffer huifu = null;
		int column = 0;
		String[] band = null;
		int[] rs;
		try {
			input = new FileReader(file);
			br = new BufferedReader(input);
			String s = br.readLine(); // �ȶ�һ�У�������ȥ����˳������
			column = s.split("\t").length;
			conn = JdbcUtils.getConnection();
			huifu = new StringBuffer();
			huifu.append(" delete from " + tableName);
			pstmt = conn.prepareStatement(huifu.toString());
			pstmt.executeUpdate();
			huifu.delete(0, huifu.length());
			huifu.append(" insert into ");
			huifu.append(tableName);
			huifu.append(" values(");
			for (int i = 1; i < column; i++)  // ѭ��������������1
				huifu.append("?,");
			huifu.append("?) ");
			pstmt = conn.prepareStatement(huifu.toString());
			while ((s = br.readLine()) != null) {
				band = s.split("\t");
				for (int k = 0; k < column; k++) {
					pstmt.setString(k + 1, band[k]);
				}
				pstmt.addBatch();
			}
			rs = pstmt.executeBatch();
			return rs.length;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
			try {
				input.close();
				br.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

}
