package CRUD;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import datasource1.JdbcUtils;

public class Login {

	//�ѹ��췽������Ϊ˽�У����ñ����ʵ������ֻ�ܵ��ø���ľ�̬����
	private Login() {}

	//�ж��Ƿ�Ϊ����Ա
	public static boolean isManager(String id, String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from ManagerTable ");
			sql.append(" where UserID  = ? ");
			sql.append(" and Passwordr  = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, ps);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	//�ж��Ƿ�Ϊ��ʦ
	public static boolean isTeacher(String id, String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from TeacherTable ");
			sql.append(" where TeacherID = ? ");
			sql.append(" and TeacherPassword = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, ps);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	//�ж��Ƿ�Ϊѧ��
	public static boolean isStudent(String id, String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from StudentTable ");
			sql.append(" where StudentID = ? ");
			sql.append(" and StudentPassword = ? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			pstmt.setString(2, ps);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				return true;
			}
			return false;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}
}
