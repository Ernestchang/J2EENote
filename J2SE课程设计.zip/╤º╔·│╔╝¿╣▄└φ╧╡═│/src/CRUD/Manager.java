package CRUD;

import info.studentinfo;
import info.teacherinfo;
import info.idinfo;
import info.nameinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

import datasource1.JdbcUtils;

public class Manager {

	//�ѹ��췽������Ϊ˽�У����ñ����ʵ������ֻ�ܵ��ø���ľ�̬����
	private Manager() {}
	// ��ȡѧ��ID,name
	public static void getSIDNAME() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		idinfo.sid.removeAllElements();
		nameinfo.sname.removeAllElements();
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentID,StudentName ");
			sql.append(" from StudentTable ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				idinfo.sid.addElement(rs.getString(1));
				nameinfo.sname.addElement(rs.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ��ʦID
	public static void getTIDNAME() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		idinfo.tid.removeAllElements();
		nameinfo.tname.removeAllElements();
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select TeacherID,TeacherName ");
			sql.append(" from TeacherTable ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				idinfo.tid.addElement(rs.getString(1));
				nameinfo.tname.addElement(rs.getString(2));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ�γ�ID
	public static void getKID() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		idinfo.kid.removeAllElements();
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select DISTINCT CourseID ");
			sql.append(" from CourseTable ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				idinfo.kid.addElement(rs.getString(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ�༶ID
	public static void getBID() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		idinfo.bid.removeAllElements();
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select DISTINCT ClassID ");
			sql.append(" from StudentTable ");
			pstmt = conn.prepareStatement(sql.toString());
			rs = pstmt.executeQuery();
			while (rs.next()) {
				idinfo.bid.addElement(rs.getString(1));
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ�û���model
	public static DefaultTableModel getUserTableModel() {
		Connection conn = null;
		Statement stmt1 = null;
		Statement stmt2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentID �û�ID,StudentPassword ���� ");
			sql.append(" from StudentTable ");
			stmt1 = conn.createStatement();
			rs1 = stmt1.executeQuery(sql.toString());
			rsmd = rs1.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs1.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs1.getString(i));
				}
				model.addRow(vector);
			}
			sql.delete(0, sql.length());
			sql.append(" select TeacherID,TeacherPassword");
			sql.append(" from TeacherTable ");
			stmt2 = conn.createStatement();
			rs2 = stmt2.executeQuery(sql.toString());
			while (rs2.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs2.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs1, stmt1, null);
			JdbcUtils.close(rs2, stmt2, conn);
		}
	}

	// ��ȡ��ʦ��model
	public static DefaultTableModel getTeacherTableModel() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql
					.append(" select TeacherID ��ʦ��,TeacherName ��ʦ��,TeacherPassword ����");
			sql.append(" from TeacherTable ");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql.toString());
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, stmt, conn);
		}
	}

	// ��ȡѧ����model
	public static DefaultTableModel getStudentTableModel() {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentID ѧ��,StudentName ����,ClassID �༶��,Class �༶��,StudentPassword ���� ");
			sql.append(" from StudentTable ");
			stmt = conn.createStatement();
			rs = stmt.executeQuery(sql.toString());
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, stmt, conn);
		}
	}

	// �޸Ĺ���Ա����
	public static int updatePS(String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" update ManagerTable ");
			sql.append(" set Passwordr=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, ps);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	// ����ѧ��
	public static boolean addStudent() {
		Connection conn = null;
		PreparedStatement pstmt1 = null;
		PreparedStatement pstmt2 = null;
		PreparedStatement pstmt3 = null;
		PreparedStatement pstmt4 = null;
		boolean a = false;
		boolean b = false;
		boolean c = false;
		boolean d = false;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql1 = new StringBuffer();
			sql1.append(" insert into StudentTable ");
			sql1.append(" values(?,?,?,?,?) ");
			pstmt1 = conn.prepareStatement(sql1.toString());
			pstmt1.setString(1, studentinfo.id);
			pstmt1.setString(2, studentinfo.name);
			pstmt1.setString(3, studentinfo.cid);
			pstmt1.setString(4, studentinfo.cname);
			pstmt1.setString(5, studentinfo.ps);
			a = (pstmt1.executeUpdate()!=0);
			StringBuffer sql2 = new StringBuffer();
			sql2.append(" insert into ScoreTable ");
			sql2.append(" values(?,?,?)");
			pstmt2 = conn.prepareStatement(sql2.toString());
			pstmt2.setString(1, "1001");
			pstmt2.setString(2, studentinfo.id);
			pstmt2.setString(3, "");
			b = (pstmt2.executeUpdate()!=0);
			StringBuffer sql3 = new StringBuffer();
			sql3.append(" insert into ScoreTable ");
			sql3.append(" values(?,?,?)");
			pstmt3 = conn.prepareStatement(sql3.toString());
			pstmt3.setString(1, "1002");
			pstmt3.setString(2, studentinfo.id);
			pstmt3.setString(3, "");
			c = (pstmt3.executeUpdate()!=0);
			StringBuffer sql4 = new StringBuffer();
			sql4.append(" insert into ScoreTable ");
			sql4.append(" values(?,?,?)");
			pstmt4 = conn.prepareStatement(sql4.toString());
			pstmt4.setString(1, "1003");
			pstmt4.setString(2, studentinfo.id);
			pstmt4.setString(3, "");
			d = (pstmt4.executeUpdate()!=0);
			return a&&b&&c&&d;
		} catch (Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			JdbcUtils.close(null, pstmt1, null);
			JdbcUtils.close(null, pstmt2, null);
			JdbcUtils.close(null, pstmt3, null);
			JdbcUtils.close(null, pstmt4, conn);
		}
	}

	// ���ӽ�ʦ
	public static int addTeacher() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" insert into TeacherTable ");
			sql.append(" values(?,?,?) ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, teacherinfo.id);
			pstmt.setString(2, teacherinfo.name);
			pstmt.setString(3, teacherinfo.ps);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	// ɾ����ʦ
	public static int deleteTeacher(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" delete from TeacherTable ");
			sql.append(" where TeacherID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	// ɾ��ѧ��
	public static int deleteStudent(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" delete from StudentTable ");
			sql.append(" where StudentID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	// ��ȡ��ѧ�Ų�ѯ��model
	public static DefaultTableModel getIDScoreTabelModel(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentTable.StudentID ѧ��,StudentTable.StudentName ����,CourseTable.CourseID �γ̺�,CourseTable.CourseName �γ���,ScoreTable.Score �ɼ� ");
			sql.append(" from ScoreTable,StudentTable,CourseTable");
			sql.append(" where StudentTable.StudentID = ScoreTable.StudentID and ScoreTable.StudentID=? and CourseTable.CourseID = ScoreTable.CourseID");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ��ѧ�����ֲ�ѯ��model
	public static DefaultTableModel getNameScoreTabelModel(String name) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentTable.StudentID ѧ��,StudentTable.StudentName ����,CourseTable.CourseID �γ̺�,CourseTable.CourseName �γ���,ScoreTable.Score �ɼ� ");
			sql.append(" from ScoreTable,StudentTable,CourseTable");
			sql.append(" where StudentTable.StudentID = ScoreTable.StudentID and StudentTable.StudentName=? and CourseTable.CourseID = ScoreTable.CourseID");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, name);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	// ��ȡ���༶�źͿγ̺Ų�ѯ��model
	public static DefaultTableModel getScoreTabelModel(String bid, String kid) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentTable.StudentID ѧ��,StudentTable.StudentName ����,CourseTable.CourseName �γ���,StudentTable.Class �༶��,ScoreTable.Score �ɼ� ");
			sql.append(" from ScoreTable,StudentTable,CourseTable");
			sql.append(" where StudentTable.StudentID = ScoreTable.StudentID and CourseTable.CourseID = ScoreTable.CourseID and StudentTable.ClassID=? and ScoreTable.CourseID=?");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, bid);
			pstmt.setString(2, kid);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

}
