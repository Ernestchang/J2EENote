package CRUD;

import info.studentinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

import datasource1.JdbcUtils;

public class Student {

	//�ѹ��췽������Ϊ˽�У����ñ����ʵ������ֻ�ܵ��ø���ľ�̬����
	private Student() {}

	//��¼��ǰ��½ѧ������Ϣ
	public static void saveStudent(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from StudentTable ");
			sql.append(" where StudentID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if(rs.next()){
				studentinfo.id = rs.getString(1);
				studentinfo.name = rs.getString(2);
				studentinfo.cid = rs.getString(3);
				studentinfo.cname = rs.getString(4);
				studentinfo.ps = rs.getString(5);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	//�޸�����
	public static int updatePS(String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" update StudentTable ");
			sql.append(" set StudentPassword=? ");
			sql.append(" where StudentID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, ps);
			pstmt.setString(2, studentinfo.id);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	//��ȡ�ɼ���
	public static DefaultTableModel getScoreModel() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		DefaultTableModel model = null;
		Vector<String> vector = null;
		int column = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentTable.StudentID ѧ��,StudentTable.StudentName ����,CourseTable.CourseID �γ̺�,CourseTable.CourseName �γ���,ScoreTable.Score �ɼ� ");
			sql.append(" from ScoreTable,StudentTable,CourseTable");
			sql.append(" where StudentTable.StudentID = ScoreTable.StudentID and ScoreTable.StudentID=? and CourseTable.CourseID = ScoreTable.CourseID");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, studentinfo.id);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

}
