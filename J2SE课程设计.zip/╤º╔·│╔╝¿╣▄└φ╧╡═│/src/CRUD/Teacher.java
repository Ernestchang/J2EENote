package CRUD;

import info.idinfo;
import info.nameinfo;
import info.teacherinfo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Vector;

import javax.swing.table.DefaultTableModel;

import datasource1.JdbcUtils;

public class Teacher {

	//�ѹ��췽������Ϊ˽�У����ñ����ʵ������ֻ�ܵ��ø���ľ�̬����
	private Teacher() {}

	// ��¼��ǰ��½��ʦ����Ϣ
	public static void saveTeacher(String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select * ");
			sql.append(" from TeacherTable ");
			sql.append(" where TeacherID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				teacherinfo.id = rs.getString(1);
				teacherinfo.name = rs.getString(2);
				teacherinfo.ps = rs.getString(3);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	//�޸�����
	public static int updatePS(String ps) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" update TeacherTable ");
			sql.append(" set TeacherPassword=? ");
			sql.append(" where TeacherID=? ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, ps);
			pstmt.setString(2, teacherinfo.id);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

	//��óɼ���
	public static DefaultTableModel getScoreTableModel() {
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		ResultSetMetaData rsmd = null;
		Vector<String> vector = null;
		DefaultTableModel model = null;
		int column = 0;
		idinfo.sid.removeAllElements();
		nameinfo.stname.removeAllElements();
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" select StudentTable.StudentID ѧ��,StudentTable.StudentName ����,CourseTable.CourseName �γ���,ScoreTable.Score �ɼ� ");
			sql.append(" from ScoreTable,StudentTable,CourseTable ");
			sql.append(" where StudentTable.StudentID=ScoreTable.StudentID and ScoreTable.CourseID=CourseTable.CourseID and ScoreTable.CourseID in( ");
			sql.append(" select CourseID ");
			sql.append(" from TeachTable ");
			sql.append(" where TeachTable.TeacherID=?) ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, teacherinfo.id);
			rs = pstmt.executeQuery();
			rsmd = rs.getMetaData();
			column = rsmd.getColumnCount();
			model = new DefaultTableModel();
			for (int i = 1; i <= column; i++) {
				model.addColumn(rsmd.getColumnName(i)); // ��������
			}
			while (rs.next()) {
				vector = new Vector<String>(); // ����������
				for (int i = 1; i <= column; i++) {
					vector.addElement(rs.getString(i));
				}
				idinfo.sid.addElement(rs.getString(1));
				nameinfo.stname.addElement(rs.getString(2));
				model.addRow(vector);
			}
			return model;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			JdbcUtils.close(rs, pstmt, conn);
		}
	}

	//�޸�ѧ���ɼ�
	public static int updateScore(String id, String score) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int rs = 0;
		try {
			conn = JdbcUtils.getConnection();
			StringBuffer sql = new StringBuffer();
			sql.append(" update ScoreTable ");
			sql.append(" set Score=? ");
			sql.append(" where StudentID=? and exists( ");
			sql.append(" select * ");
			sql.append(" from TeachTable ");
			sql.append(" where  TeachTable.CourseID=ScoreTable.CourseID and TeachTable.TeacherID=?)  ");
			pstmt = conn.prepareStatement(sql.toString());
			pstmt.setString(1, score);
			pstmt.setString(2, id);
			pstmt.setString(3, teacherinfo.id);
			rs = pstmt.executeUpdate();
			return rs;
		} catch (Exception e) {
			e.printStackTrace();
			return rs;
		} finally {
			JdbcUtils.close(null, pstmt, conn);
		}
	}

}
