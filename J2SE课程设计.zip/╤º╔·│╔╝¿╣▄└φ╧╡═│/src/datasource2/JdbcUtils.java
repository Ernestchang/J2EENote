package datasource2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public final class JdbcUtils {
	private static final String DRIVER = "com.kingbase.Driver";
	private static MyDataSource myDataSource = null;
	private JdbcUtils() {}

	static {
		try {
			Class.forName(DRIVER);
			myDataSource = new MyDataSource();
		}
		catch(Exception e) {
			throw new ExceptionInInitializerError(e);
		}
	}

	public static Connection getConnection() throws SQLException {
		return myDataSource.getConnection();
	}

	public static void close(ResultSet rs, Statement st, Connection conn) {
		try {
			if(rs != null) {
				rs.close();
				rs = null;
			}
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			try {
				if(st != null) {
					st.close();
					st = null;
				}
			}
			catch(SQLException e) {
				e.printStackTrace();
			}
			finally {
				try {
					if(conn != null) {
						conn.close();
					}
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
	}
}
