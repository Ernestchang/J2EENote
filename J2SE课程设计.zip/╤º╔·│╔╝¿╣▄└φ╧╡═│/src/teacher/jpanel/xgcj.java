package teacher.jpanel;

import info.idinfo;
import info.nameinfo;

import java.awt.BorderLayout;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;

import CRUD.Teacher;

//��ʦ�޸ĳɼ����
public class xgcj extends JPanel implements MouseListener {

	private static final long serialVersionUID = 1L;
	private JSplitPane jSplitPane = null;
	private JList xh = null;
	private JList xm = null;
	private String sid = null;
	private String score = null;
	private JScrollPane jScrollPane = null;
	private JLabel jLabel = null;
	private JPanel jPanel = null;

	public xgcj() {
		super();
		initialize();
	}

	private void initialize() {
		Teacher.getScoreTableModel();
		jLabel = new JLabel(
				"   ѧ��                                                           ����");
		this.setLayout(new BorderLayout());
		this.add(getJPanel(), BorderLayout.CENTER);
	}

	private JScrollPane getJScrollPane() {
		if (jScrollPane == null) {
			jScrollPane = new JScrollPane();
			jScrollPane.setViewportView(getJSplitPane());

		}
		return jScrollPane;
	}

	private JPanel getJPanel() {
		if (jPanel == null) {
			jPanel = new JPanel();
			jPanel.setBorder(BorderFactory.createTitledBorder("��˫����Ҫ�޸ĵ�ѧ���Ż�ѧ����"));
			jPanel.setLayout(new BorderLayout());
			jPanel.add(jLabel, BorderLayout.NORTH);
			jPanel.add(getJScrollPane(), BorderLayout.CENTER);
		}
		return jPanel;
	}

	private JSplitPane getJSplitPane() {
		if (jSplitPane == null) {
			jSplitPane = new JSplitPane();
			jSplitPane.setDividerSize(2);
			jSplitPane.setEnabled(false);
			jSplitPane.setDividerLocation(200);
			jSplitPane.setLeftComponent(getXh());
			jSplitPane.setRightComponent(getXm());

		}
		return jSplitPane;
	}

	private JList getXh() {
		if (xh == null) {
			xh = new JList(idinfo.sid);
			xh.addMouseListener(this);
		}
		return xh;
	}

	private JList getXm() {
		if (xm == null) {
			xm = new JList();
			xm = new JList(nameinfo.stname);
			xm.addMouseListener(this);
		}
		return xm;
	}

	public void action() {
		sid = (String) xh.getSelectedValue();
		if (sid != null) {
			score = JOptionPane.showInputDialog(null, null,"�������ѧ���ĳɼ�", JOptionPane.DEFAULT_OPTION);
			if (Integer.parseInt(score) >= 0 && Integer.parseInt(score) <= 100) {
				if (Teacher.updateScore(sid, score) > 0)
					JOptionPane.showMessageDialog(null, "�޸ĳɹ�","������ʾ",JOptionPane.INFORMATION_MESSAGE);
				else
					JOptionPane.showMessageDialog(null, "�޸�ʧ��","������ʾ", JOptionPane.WARNING_MESSAGE);
			}
			else
				JOptionPane.showMessageDialog(null, "�ɼ�������0��100֮��","������ʾ", JOptionPane.WARNING_MESSAGE);
		}
	}

	public void mouseClicked(MouseEvent e) {

		if (e.getClickCount() == 2)
			action();
	}

	public void mouseEntered(MouseEvent e) {}

	public void mouseExited(MouseEvent e) {}

	public void mousePressed(MouseEvent e) {
		if(e.getSource() == xm)
			xh.setSelectedIndex(xm.getSelectedIndex());
		if(e.getSource() == xh)
			xm.setSelectedIndex(xh.getSelectedIndex());
	}

	public void mouseReleased(MouseEvent e) {}

}
