import javax.swing.UIManager;

import frame.LoginFrame;


public class start {
	public static void main(String[] args) {
		//���ý���Ƥ��
		try {
			UIManager.setLookAndFeel("com.birosoft.liquid.LiquidLookAndFeel");
			com.birosoft.liquid.LiquidLookAndFeel.setLiquidDecorations(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
		//�򿪵�¼����
		new LoginFrame();
	}
}
