//**********************************************************
//����������               ѧ�ţ�1007092136
//**********************************************************
import java.awt.*;
import java.awt.event.*;
import java.util.Random;
import javax.swing.*;
import javax.swing.border.BevelBorder;
@SuppressWarnings("serial")
public class Mora extends JFrame implements MouseListener
{
	JPanel panel1,panel2,panel3;
	JLabel computer,result,person;
	ImageIcon ShiTou,JianZi,Bu,shu,ying,ping;
	JButton shitou,jianzi,bu;
	Random generator;
	int c = 0,p = 0,total = 0;
	public Mora()
	{
		setTitle("ʯͷ������");
		Container c = getContentPane();
		generator = new Random();
		ShiTou = new ImageIcon("shitou.png");
		JianZi = new ImageIcon("jianzi.png");
		Bu = new ImageIcon("bu.png");
		ping = new ImageIcon("ping.png");
		shu = new ImageIcon("shu.png");
		ying = new ImageIcon("ying.png");
		person = new JLabel(new ImageIcon("caiquan.png"));
		person.addMouseListener(this);
		result = new JLabel(new ImageIcon("vs.png"));
		result.addMouseListener(this);
		computer = new JLabel(new ImageIcon("caiquan.png"));
		computer.addMouseListener(this);
		panel1 = new JPanel();
		panel1.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		panel1.setLayout(new BoxLayout(panel1,BoxLayout.X_AXIS));
		panel1.add(person);
		panel1.add(result);
		panel1.add(computer);
		panel1.setPreferredSize(new Dimension(450,200));
		shitou = new JButton(new ImageIcon("ansitou.png"));
		shitou.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		shitou.addMouseListener(this);
		jianzi = new JButton(new ImageIcon("anjianzi.png"));
		jianzi.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		jianzi.addMouseListener(this);
		bu = new JButton(new ImageIcon("anbu.png"));
		bu.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		bu.addMouseListener(this);
		panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2,BoxLayout.X_AXIS));
		panel2.add(jianzi);
		panel2.add(Box.createRigidArea(new Dimension(17,0)));
		panel2.add(shitou);
		panel2.add(Box.createRigidArea(new Dimension(16,0)));
		panel2.add(bu);
		panel2.setPreferredSize(new Dimension(450,103));
		panel2.setBackground(new Color(200,218,235));
		panel3 = new JPanel();
		panel3.setBackground(new Color(200,218,235));
		panel3.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));
		panel3.setLayout(new BoxLayout(panel3,BoxLayout.Y_AXIS));
		panel3.add(panel1);
		panel3.add(panel2);
		c.add(panel3);
		pack();
		setResizable(false);
		setVisible(true);
	}
	public void mousePressed(MouseEvent event)
	{
		Object source = event.getSource();
		int ran = generator.nextInt(3);
		if(source == jianzi)
		{
			person.setIcon(JianZi);
			if(ran == 0)
			{
				total += 1;
				result.setIcon(ping);
				computer.setIcon(JianZi);
			}
			if(ran == 1)
			{
				total += 1;
				c += 1;
				result.setIcon(shu);
				computer.setIcon(ShiTou);
			}
			if(ran == 2)
			{
				total += 1;
				p += 1;
				result.setIcon(ying);
				computer.setIcon(Bu);
			}
		}
		if(source == shitou)
		{
			person.setIcon(ShiTou);
			if(ran == 0)
			{
				total += 1;
				p += 1;
				result.setIcon(ying);
				computer.setIcon(JianZi);
			}
			if(ran == 1)
			{
				total += 1;
				result.setIcon(ping);
				computer.setIcon(ShiTou);
			}
			if(ran == 2)
			{
				total += 1;
				c += 1;
				result.setIcon(shu);
				computer.setIcon(Bu);
			}
		}		
		if(source == bu)
		{
			person.setIcon(Bu);
			if(ran == 0)
			{
				total += 1;
				c += 1;
				result.setIcon(shu);
				computer.setIcon(JianZi);
			}
			if(ran == 1)
			{
				total += 1;
				p += 1;
				result.setIcon(ying);
				computer.setIcon(ShiTou);
			}
			if(ran == 2)
			{
				total += 1;
				result.setIcon(ping);
				computer.setIcon(Bu);
			}
		}
		if(source == jianzi || source == shitou || source == bu)
		{
			int again = JOptionPane.showConfirmDialog(panel2,"Ŀǰ������"+total+"��     ��Ӯ��"+p+"��    ����Ӯ��"+c+"��   ��Ҫ��������"
					,"��ʾ",JOptionPane.YES_NO_OPTION);
			if(again==JOptionPane.NO_OPTION)
				System.exit(0);
		}
	}
	public void mouseEntered(MouseEvent arg0) {}
	public void mouseExited(MouseEvent arg0) {}
	public void mouseClicked(MouseEvent arg0) {}
	public void mouseReleased(MouseEvent arg0) {}
	public static void main(String[] args)
	{
		Mora mora = new Mora();
		mora.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}